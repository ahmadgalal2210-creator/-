import type { WorkspaceState } from '../types';
import {
  buildLightweightWorkspaceForExport,
  isStandaloneOfflineMode,
} from './offlineRuntime';

function safeJsonForHtmlScript(obj: unknown): string {
  return JSON.stringify(obj)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/&/g, '\\u0026')
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');
}

function injectSeedIntoTemplate(templateHtml: string, workspace: WorkspaceState): string {
  const lightWs = buildLightweightWorkspaceForExport(workspace);
  const payloadJson = safeJsonForHtmlScript(lightWs);

  if (templateHtml.includes('__OFFLINE_SEED_JSON__')) {
    return templateHtml.replace('__OFFLINE_SEED_JSON__', () => payloadJson);
  }

  return templateHtml.replace(
    /(<script\s+id="offline-seed-data"\s+type="application\/json">)[\s\S]*?(<\/script>)/i,
    (_m, openTag, closeTag) => `${openTag}${payloadJson}${closeTag}`
  );
}

export async function buildStandaloneOfflineHtml(
  workspace: WorkspaceState
): Promise<string> {
  // If already running inside an exported standalone offline HTML file,
  // clone the current clean template shell without bloating the DOM.
  if (isStandaloneOfflineMode() && typeof document !== 'undefined') {
    const clone = document.documentElement.cloneNode(true) as HTMLElement;
    const rootEl = clone.querySelector('#root');
    if (rootEl) rootEl.innerHTML = '';
    const seedEl = clone.querySelector('#offline-seed-data');
    if (seedEl) {
      seedEl.textContent = safeJsonForHtmlScript(
        buildLightweightWorkspaceForExport(workspace)
      );
    }
    return `<!doctype html>\n${clone.outerHTML}`;
  }

  const res = await fetch('/offline-template.html', { cache: 'no-store' });
  if (!res.ok) {
    throw new Error('تعذر تحميل قالب النسخة الأوفلاين الموحدة.');
  }
  const templateHtml = await res.text();
  return injectSeedIntoTemplate(templateHtml, workspace);
}
