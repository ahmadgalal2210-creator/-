import { AlignmentType, Document, Packer, Paragraph, TextRun } from 'docx';
import mammoth from 'mammoth';
import * as XLSX from 'xlsx';
import type { FileCategory, SheetPreviewData } from '../types';

export function makeSafeId(prefix: string): string {
  const cleanPrefix = prefix.replace(/[^a-zA-Z0-9_-]/g, '') || 'item';
  const rand = Math.random().toString(36).slice(2, 8);
  return `${cleanPrefix}_${Date.now().toString(36)}_${rand}`;
}

export function cleanFileTitle(fileName: string): string {
  return fileName
    .replace(/\.[^.]+$/, '')
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim() || fileName;
}

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 B';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export function formatDateAr(iso?: string): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso.slice(0, 10);
  try {
    return d.toLocaleDateString('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return iso.slice(0, 10);
  }
}

export function isImageFile(file: File): boolean {
  const name = file.name.toLowerCase();
  return (
    file.type.startsWith('image/') ||
    /\.(png|jpe?g|webp|gif|bmp|svg)$/i.test(name)
  );
}

function detectCategory(file: File): FileCategory {
  const name = file.name.toLowerCase();
  if (/\.(docx?|rtf|odt)$/i.test(name) || file.type.includes('word')) return 'word';
  if (/\.(xlsx?|csv|ods)$/i.test(name) || file.type.includes('sheet') || file.type.includes('excel')) {
    return 'excel';
  }
  if (/\.pdf$/i.test(name) || file.type === 'application/pdf') return 'pdf';
  return 'other';
}

function extractHeadingsFromLines(text: string): string[] {
  const lines = text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length >= 4 && l.length <= 120);
  const headings: string[] = [];
  const seen = new Set<string>();
  for (const line of lines) {
    const looksLikeHeading =
      /^(\d+[\.\-\)]|أولاً|ثانياً|ثالثاً|رابعاً|خامساً|الفصل|الباب|المبحث|القسم|مقدمة|خاتمة|النتائج|التوصيات|الموضوع|الملخص|Chapter|Section|Abstract|Conclusion)/i.test(
        line
      ) ||
      (line.length <= 65 && !/[.،؛?!]$/.test(line));
    if (looksLikeHeading && !seen.has(line)) {
      seen.add(line);
      headings.push(line);
      if (headings.length >= 40) break;
    }
  }
  return headings;
}

function extractReadablePdfStrings(buffer: ArrayBuffer): string {
  try {
    const bytes = new Uint8Array(buffer.slice(0, 600_000));
    const decoded = new TextDecoder('latin1').decode(bytes);
    const chunks: string[] = [];
    const regex = /\(([^()\\]{3,160})\)/g;
    let m: RegExpExecArray | null;
    while ((m = regex.exec(decoded)) !== null) {
      const cleaned = m[1]
        .replace(/[^\u0600-\u06FFa-zA-Z0-9\s.,:\-\/()]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
      if (cleaned.length >= 4 && /[a-zA-Z\u0600-\u06FF]{2,}/.test(cleaned)) {
        chunks.push(cleaned);
      }
      if (chunks.length >= 160) break;
    }
    return chunks.join('\n').slice(0, 15000);
  } catch {
    return '';
  }
}

export function buildSummaryFromParsed(params: {
  title: string;
  fileName: string;
  category: FileCategory;
  headings: string[];
  extractedText: string;
  sheetPreview: SheetPreviewData[];
}): string {
  const { title, fileName, category, headings, extractedText, sheetPreview } = params;
  if (category === 'excel' && sheetPreview.length > 0) {
    const sheetSummaries = sheetPreview.slice(0, 5).map((s) => {
      const cols = s.headers.filter(Boolean).slice(0, 6).join('، ');
      return `• ورقة «${s.sheetName}»: (${s.rows.length} صف) — الأعمدة: ${cols || 'بيانات جدولية'}`;
    });
    return `ملخص ملف الإكسيل (${fileName}):\nالعنوان: ${title}\n${sheetSummaries.join('\n')}`;
  }
  if (extractedText.trim()) {
    const cleanLines = extractedText
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter((l) => l.length > 3);
    const previewLines = cleanLines.slice(0, 6).join('\n');
    const headingNote =
      headings.length > 0 ? `\nأبرز العناوين: ${headings.slice(0, 4).join(' · ')}` : '';
    return `ملخص المحتوى (${title}):\n${previewLines}${headingNote}`.slice(0, 2200);
  }
  if (category === 'pdf') {
    return `ملخص مستند PDF المرفق (${fileName}):\nالعنوان: ${title}\nتم تجهيز الملف للعرض والرد عليه وتحويله إلى صيغة Word قابلة للتعديل والطباعة.`;
  }
  return `ملخص الملف المرفق (${fileName}):\nالعنوان: ${title}`;
}

export async function parseDocumentFile(file: File): Promise<{
  category: FileCategory;
  suggestedTitle: string;
  headings: string[];
  extractedText: string;
  sheetPreview: SheetPreviewData[];
  summaryText: string;
}> {
  const category = detectCategory(file);
  const baseTitle = cleanFileTitle(file.name);
  let extractedText = '';
  let headings: string[] = [];
  let sheetPreview: SheetPreviewData[] = [];

  try {
    if (category === 'word' && /\.docx$/i.test(file.name)) {
      const buf = await file.arrayBuffer();
      const raw = await mammoth.extractRawText({ arrayBuffer: buf });
      extractedText = (raw.value || '').trim().slice(0, 28000);
      headings = extractHeadingsFromLines(extractedText);
    } else if (category === 'excel') {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: 'array' });
      const sheetNames = wb.SheetNames.slice(0, 10);
      headings = sheetNames.map((n) => `ورقة: ${n}`);
      const textParts: string[] = [];
      sheetPreview = sheetNames.map((name) => {
        const ws = wb.Sheets[name];
        const rowsRaw = XLSX.utils.sheet_to_json<unknown[]>(ws, {
          header: 1,
          defval: '',
        });
        const normalizedRows = rowsRaw
          .slice(0, 61)
          .map((r) =>
            (Array.isArray(r) ? r : [])
              .slice(0, 50)
              .map((cell) => String(cell ?? '').trim().slice(0, 120))
          );
        const headers = normalizedRows[0] || [];
        const rows = normalizedRows.slice(1, 61);
        textParts.push(
          `[${name}]\n${headers.join(' | ')}\n${rows
            .slice(0, 15)
            .map((r) => r.join(' | '))
            .join('\n')}`
        );
        return { sheetName: name, headers, rows };
      });
      extractedText = textParts.join('\n\n').slice(0, 28000);
    } else if (category === 'pdf') {
      const buf = await file.arrayBuffer();
      extractedText = extractReadablePdfStrings(buf);
      headings = extractHeadingsFromLines(extractedText);
    } else if (/text|json|csv|markdown/i.test(file.type) || /\.(txt|md|csv|log)$/i.test(file.name)) {
      extractedText = (await file.text()).slice(0, 28000);
      headings = extractHeadingsFromLines(extractedText);
    }
  } catch {
    // Graceful fallback if binary parser encounters an unusual format
  }

  const firstMeaningfulLine = extractedText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .find((l) => l.length >= 5 && l.length <= 120 && !/^\[/.test(l));

  const suggestedTitle =
    headings[0]?.replace(/^ورقة:\s*/, '') || firstMeaningfulLine || baseTitle;

  const summaryText = buildSummaryFromParsed({
    title: suggestedTitle,
    fileName: file.name,
    category,
    headings,
    extractedText,
    sheetPreview,
  });

  return {
    category,
    suggestedTitle: suggestedTitle.slice(0, 190),
    headings: headings.slice(0, 60),
    extractedText,
    sheetPreview,
    summaryText,
  };
}

export async function processImageFile(file: File): Promise<{
  thumbnailDataUrl: string;
  width: number;
  height: number;
  summaryText: string;
}> {
  const title = cleanFileTitle(file.name);
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const maxDim = 900;
        const scale = Math.min(1, maxDim / Math.max(img.width || 1, img.height || 1));
        const targetW = Math.max(1, Math.round(img.width * scale));
        const targetH = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = targetW;
        canvas.height = targetH;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, targetW, targetH);
          let dataUrl = canvas.toDataURL('image/jpeg', 0.72);
          if (dataUrl.length > 220000) {
            dataUrl = canvas.toDataURL('image/jpeg', 0.45);
          }
          resolve({
            thumbnailDataUrl: dataUrl.slice(0, 245000),
            width: img.width,
            height: img.height,
            summaryText: `ملخص الصورة المرفقة (${file.name}):\nالعنوان: ${title}\nالأبعاد: ${img.width} × ${img.height} بكسل — جاهزة للعرض والتحويل لمستند رد Word.`,
          });
          return;
        }
        resolve({
          thumbnailDataUrl: '',
          width: img.width,
          height: img.height,
          summaryText: `ملخص الصورة المرفقة (${file.name}): ${title}`,
        });
      };
      img.onerror = () =>
        resolve({
          thumbnailDataUrl: '',
          width: 0,
          height: 0,
          summaryText: `ملخص الصورة المرفقة (${file.name}): ${title}`,
        });
      img.src = String(reader.result || '');
    };
    reader.onerror = () =>
      resolve({
        thumbnailDataUrl: '',
        width: 0,
        height: 0,
        summaryText: `ملخص الصورة المرفقة (${file.name}): ${title}`,
      });
    reader.readAsDataURL(file);
  });
}

export async function generateWordDocxBlob(params: {
  title: string;
  departmentName?: string;
  refNumber?: string;
  bodyText: string;
  subTitle?: string;
}): Promise<Blob> {
  const { title, departmentName, refNumber, bodyText, subTitle } = params;
  const paragraphs: Paragraph[] = [
    new Paragraph({
      alignment: AlignmentType.LEFT,
      children: [
        new TextRun({
          text: 'شركة الدقهلية لصناعة وتكرير السكر',
          bold: true,
          size: 28,
        }),
      ],
    }),
    new Paragraph({
      alignment: AlignmentType.LEFT,
      spacing: { after: 240 },
      children: [
        new TextRun({
          text: subTitle || 'الإدارة العامة للبيئة والسلامة المهنية',
          size: 22,
          color: '475569',
        }),
      ],
    }),
    new Paragraph({
      alignment: AlignmentType.RIGHT,
      bidirectional: true,
      spacing: { before: 120, after: 120 },
      children: [
        new TextRun({
          text: title || 'مذكرة عمل',
          bold: true,
          size: 30,
        }),
      ],
    }),
  ];

  if (departmentName || refNumber) {
    paragraphs.push(
      new Paragraph({
        alignment: AlignmentType.RIGHT,
        bidirectional: true,
        spacing: { after: 160 },
        children: [
          new TextRun({
            text: [
              departmentName ? `الجهة / الإدارة: ${departmentName}` : '',
              refNumber ? `المرجع: ${refNumber}` : '',
            ]
              .filter(Boolean)
              .join('  |  '),
            size: 20,
            color: '64748B',
          }),
        ],
      })
    );
  }

  const bodyLines = (bodyText || '').split(/\r?\n/);
  for (const line of bodyLines) {
    paragraphs.push(
      new Paragraph({
        alignment: AlignmentType.RIGHT,
        bidirectional: true,
        spacing: { after: 100 },
        children: [
          new TextRun({
            text: line || ' ',
            size: 24,
          }),
        ],
      })
    );
  }

  const doc = new Document({
    sections: [{ children: paragraphs }],
  });
  return Packer.toBlob(doc);
}
