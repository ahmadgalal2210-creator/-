import { useEffect, useRef, useState } from 'react';
import type { User } from 'firebase/auth';
import {
  ArrowLeftRight,
  CheckCircle2,
  Cloud,
  CloudDownload,
  CloudUpload,
  FileJson,
  HardDrive,
  Link2,
  LogOut,
  RefreshCw,
  Sparkles,
  WifiOff,
  X,
} from 'lucide-react';
import { formatDateAr } from '../lib/fileParser';
import {
  countWorkspaceItems,
  loadLocalWorkspace,
  parseWorkspaceBackupJson,
} from '../lib/localWorkspaceService';
import { mergeWorkspaces, type SyncDiffSummary } from '../lib/syncEngine';
import { isStandaloneOfflineMode } from '../lib/offlineRuntime';
import { fetchCloudWorkspaceOnce } from '../lib/workspaceService';
import type { WorkspaceState } from '../types';

export type SyncStrategy = 'merge' | 'push_local' | 'pull_cloud';

interface SyncModalProps {
  open: boolean;
  user: User | null;
  localMode: boolean;
  isOnline: boolean;
  hasPendingSync: boolean;
  lastSyncedAt: string | null;
  linkedHint: { email: string; displayName: string } | null;
  workspace: WorkspaceState;
  onClose: () => void;
  onLinkGoogle: () => Promise<User | null>;
  onExecuteSync: (
    strategy: SyncStrategy,
    targetUser: User,
    localWs: WorkspaceState,
    cloudWs: WorkspaceState
  ) => Promise<void>;
  onCleanCloudForDev: (targetUser: User, cloudWs: WorkspaceState) => Promise<void>;
  onSwitchToOffline: () => Promise<void>;
  onSwitchToOnline: () => void;
  onMergeImportedJson: (imported: WorkspaceState) => Promise<void>;
  onSignOutGoogle: () => Promise<void>;
  onToast: (msg: string) => void;
}

export function SyncModal({
  open,
  user,
  localMode,
  isOnline,
  hasPendingSync,
  lastSyncedAt,
  linkedHint,
  workspace,
  onClose,
  onLinkGoogle,
  onExecuteSync,
  onCleanCloudForDev,
  onSwitchToOffline,
  onSwitchToOnline,
  onMergeImportedJson,
  onSignOutGoogle,
  onToast,
}: SyncModalProps) {
  const [loadingCloud, setLoadingCloud] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [linking, setLinking] = useState(false);
  const [localWs, setLocalWs] = useState<WorkspaceState | null>(null);
  const [cloudWs, setCloudWs] = useState<WorkspaceState | null>(null);
  const [summary, setSummary] = useState<SyncDiffSummary | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const jsonInputRef = useRef<HTMLInputElement>(null);
  const standaloneOffline = isStandaloneOfflineMode();

  const inspectBothSides = async (activeUser: User | null, currentLocal?: WorkspaceState) => {
    setErrorMsg(null);
    const localData = currentLocal || (localMode ? workspace : await loadLocalWorkspace());
    setLocalWs(localData);

    if (standaloneOffline || !activeUser || !isOnline) {
      setCloudWs(null);
      setSummary(null);
      return null;
    }

    setLoadingCloud(true);
    try {
      const cloudData = await fetchCloudWorkspaceOnce(activeUser.uid);
      setCloudWs(cloudData);
      const { summary: s } = mergeWorkspaces(localData, cloudData, true);
      setSummary(s);
      return { localData, cloudData };
    } catch (err) {
      setErrorMsg(
        err instanceof Error
          ? 'تعذر قراءة بيانات السحابة حالياً — تأكد من الاتصال بالإنترنت وحاول مجدداً.'
          : 'تعذر الاتصال بالسحابة حالياً.'
      );
      return null;
    } finally {
      setLoadingCloud(false);
    }
  };

  useEffect(() => {
    if (!open) return;
    void inspectBothSides(user);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, user?.uid, isOnline, localMode]);

  if (!open) return null;

  const localDisplayCount = localWs
    ? countWorkspaceItems(localWs)
    : countWorkspaceItems(workspace);

  const handleConnectGoogle = async () => {
    if (standaloneOffline) {
      setErrorMsg(
        'الربط المباشر بحساب جوجل متاح عبر رابط النسخة الأونلاين أو تطبيق PWA. يمكنك من الأسفل دمج أو تصدير ملف (.json) للمزامنة مع السحابة.'
      );
      return;
    }
    if (!isOnline) {
      setErrorMsg('جهازك غير متصل بالإنترنت حالياً. اتصل بالإنترنت أولاً لإتمام ربط حساب جوجل.');
      return;
    }
    setLinking(true);
    setErrorMsg(null);
    try {
      const linkedUser = await onLinkGoogle();
      if (linkedUser) {
        onToast(`تم ربط حساب جوجل: ${linkedUser.email || 'د. أيمن عبد الحميد'} — جاري سحب قاعدة البيانات...`);
        const inspected = await inspectBothSides(linkedUser, localWs || workspace);
        if (inspected && countWorkspaceItems(inspected.localData) === 0 && countWorkspaceItems(inspected.cloudData) > 0) {
          await onExecuteSync('pull_cloud', linkedUser, inspected.localData, inspected.cloudData);
          onClose();
        }
      }
    } catch (err) {
      setErrorMsg(
        err instanceof Error ? err.message : 'تعذر إتمام الربط بحساب جوجل.'
      );
    } finally {
      setLinking(false);
    }
  };

  const handleRunSync = async (strategy: SyncStrategy) => {
    if (!isOnline) {
      setErrorMsg('أنت غير متصل بالإنترنت حالياً — لا يمكن المزامنة السحابية قبل عودة الاتصال.');
      return;
    }
    let activeUser = user;
    if (!activeUser) {
      setLinking(true);
      try {
        activeUser = await onLinkGoogle();
      } catch (err) {
        setErrorMsg(err instanceof Error ? err.message : 'تعذر الربط بحساب جوجل.');
        setLinking(false);
        return;
      }
      setLinking(false);
      if (!activeUser) return;
    }

    setSyncing(true);
    setErrorMsg(null);
    try {
      const lData = localWs || (localMode ? workspace : await loadLocalWorkspace());
      const cData = cloudWs || (await fetchCloudWorkspaceOnce(activeUser.uid));
      await onExecuteSync(strategy, activeUser, lData, cData);
      onClose();
    } catch (err) {
      setErrorMsg(
        err instanceof Error ? err.message : 'حدث خطأ أثناء تنفيذ المزامنة.'
      );
    } finally {
      setSyncing(false);
    }
  };

  const handleCleanCloud = async () => {
    if (!user || !isOnline) {
      setErrorMsg('يجب الاتصال بالإنترنت وربط حساب جوجل لتنظيف السحابة.');
      return;
    }
    setSyncing(true);
    setErrorMsg(null);
    try {
      const cData = cloudWs || (await fetchCloudWorkspaceOnce(user.uid));
      await onCleanCloudForDev(user, cData);
      await inspectBothSides(user);
    } catch (err) {
      setErrorMsg(
        err instanceof Error ? err.message : 'تعذر تفريغ البيانات التجريبية في السحابة.'
      );
    } finally {
      setSyncing(false);
    }
  };

  const handleJsonMergeUpload = async (file: File) => {
    setSyncing(true);
    setErrorMsg(null);
    try {
      const parsed = await parseWorkspaceBackupJson(file);
      await onMergeImportedJson(parsed);
      onToast('تم دمج ملف الأوفلاين مع مساحة العمل بنجاح');
      await inspectBothSides(user);
    } catch {
      setErrorMsg('تعذر قراءة ملف الأوفلاين (.json). تأكد أنه ملف نسخة صالحة.');
    } finally {
      setSyncing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="fixed inset-0 bg-slate-950/45"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        role="dialog"
        aria-modal="true"
        className="relative z-10 w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xl max-h-[90vh] flex flex-col overflow-hidden"
      >
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ArrowLeftRight className="w-5 h-5 text-blue-700 dark:text-blue-400" />
            <div>
              <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">
                المزامنة وربط حساب جوجل (أونلاين ⇄ أوفلاين)
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                سحب قاعدة البيانات من السحابة فور الربط، والمزامنة الثنائية، وتفريغ البيانات التجريبية للتطوير
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
            aria-label="إغلاق"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-4 overflow-y-auto">
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                {user?.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.displayName || 'حساب جوجل'}
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-400 flex items-center justify-center shrink-0">
                    {user ? <Cloud className="w-5 h-5" /> : <HardDrive className="w-5 h-5" />}
                  </div>
                )}
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    {user
                      ? `مرتبط بحساب جوجل: ${user.email}`
                      : linkedHint
                        ? `آخر حساب جوجل مرتبط: ${linkedHint.email}`
                        : 'يعمل حالياً في وضع الأوفلاين المحلي بدون ربط بجوجل'}
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 flex flex-wrap items-center gap-2">
                    <span>
                      الوضع النشط:{' '}
                      <strong className="text-slate-800 dark:text-slate-200">
                        {localMode ? 'وضع الأوفلاين (جهازك)' : 'وضع الأونلاين (حساب جوجل)'}
                      </strong>
                    </span>
                    {lastSyncedAt && (
                      <span>· آخر مزامنة: {formatDateAr(lastSyncedAt)}</span>
                    )}
                  </p>
                </div>
              </div>

              {!user ? (
                <button
                  type="button"
                  disabled={linking || !isOnline}
                  onClick={() => void handleConnectGoogle()}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-blue-700 text-white text-xs font-semibold hover:bg-blue-800 disabled:opacity-60"
                >
                  <Link2 className="w-3.5 h-3.5" />
                  {linking ? 'جاري الربط وسحب السحابة...' : 'ربط حساب جوجل وسحب السحابة'}
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => void inspectBothSides(user)}
                  disabled={loadingCloud || !isOnline}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingCloud ? 'animate-spin' : ''}`} />
                  سحب / فحص السحابة
                </button>
              )}
            </div>

            {!isOnline && (
              <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-xs text-amber-800 dark:text-amber-300">
                <WifiOff className="w-4 h-4 shrink-0" />
                <span>
                  الجهاز غير متصل بالإنترنت حالياً — كل تعديلاتك محفوظة محلياً، وعند عودة الإنترنت اضغط «طلب المزامنة».
                </span>
              </div>
            )}

            {hasPendingSync && isOnline && (
              <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 text-xs text-blue-800 dark:text-blue-300">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>
                  توجد تعديلات محلية مسجلة أثناء الأوفلاين جاهزة للمزامنة مع حساب جوجل الآن.
                </span>
              </div>
            )}
          </div>

          {errorMsg && (
            <div className="p-3 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-xs text-red-700 dark:text-red-300">
              {errorMsg}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950">
              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                <span>نسخة الأوفلاين (على الجهاز)</span>
                <HardDrive className="w-4 h-4 text-slate-600 dark:text-slate-300" />
              </div>
              <p className="font-mono text-2xl font-bold text-slate-900 dark:text-white mt-2 tabular-nums">
                {localDisplayCount}
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                {summary && summary.localOnlyCount > 0
                  ? `${summary.localOnlyCount} عنصر جديد على الجهاز غير مرفوع بعد`
                  : 'محفوظ محلياً للعمل بدون إنترنت'}
              </p>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950">
              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                <span>نسخة الأونلاين (حساب جوجل)</span>
                <Cloud className="w-4 h-4 text-blue-700 dark:text-blue-400" />
              </div>
              <p className="font-mono text-2xl font-bold text-slate-900 dark:text-white mt-2 tabular-nums">
                {loadingCloud
                  ? '...'
                  : user && isOnline && cloudWs
                    ? countWorkspaceItems(cloudWs)
                    : '—'}
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                {!user
                  ? 'اربط حساب جوجل لعرض وسحب عناصر السحابة'
                  : loadingCloud
                    ? 'جاري سحب بيانات السحابة...'
                    : summary && summary.cloudOnlyCount > 0
                      ? `${summary.cloudOnlyCount} عنصر على حساب جوجل غير موجود محلياً`
                      : 'متاح عبر حساب جوجل من أي جهاز'}
              </p>
            </div>
          </div>

          <div className="space-y-2.5">
            <button
              type="button"
              disabled={syncing || linking || loadingCloud || !isOnline}
              onClick={() => void handleRunSync('merge')}
              className="w-full flex items-center justify-between gap-3 p-3.5 rounded-xl bg-blue-700 text-white hover:bg-blue-800 disabled:opacity-60 transition-colors text-right"
            >
              <div className="flex items-center gap-3">
                <RefreshCw className={`w-5 h-5 shrink-0 ${syncing ? 'animate-spin' : ''}`} />
                <div>
                  <p className="text-sm font-bold">
                    {syncing
                      ? 'جاري تنفيذ المزامنة الثنائية...'
                      : 'طلب المزامنة والدمج الذكي (الأوفلاين ⇄ الأونلاين)'}
                  </p>
                  <p className="text-[11px] text-blue-100">
                    {user
                      ? 'يسحب السحابة ويدمج بيانات الأوفلاين مع حساب جوجل بدون حذف أي ملف'
                      : 'يربط حساب جوجل ثم يسحب ويدمج بيانات الأوفلاين مع السحابة فوراً'}
                  </p>
                </div>
              </div>
              {summary && (
                <span className="font-mono text-xs bg-white/15 px-2.5 py-1 rounded-md shrink-0 tabular-nums">
                  {summary.mergedCount} عنصر
                </span>
              )}
            </button>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                type="button"
                disabled={syncing || linking || loadingCloud || !isOnline}
                onClick={() => void handleRunSync('pull_cloud')}
                className="flex items-center gap-2.5 p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-60 text-right"
              >
                <CloudDownload className="w-4 h-4 text-blue-700 dark:text-blue-400 shrink-0" />
                <div>
                  <p className="text-xs font-bold text-slate-900 dark:text-white">
                    سحب قاعدة البيانات من السحابة
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    جلب بيانات السحابة واعتمادها الآن
                  </p>
                </div>
              </button>

              <button
                type="button"
                disabled={syncing || linking || loadingCloud || !isOnline}
                onClick={() => void handleRunSync('push_local')}
                className="flex items-center gap-2.5 p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-60 text-right"
              >
                <CloudUpload className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
                <div>
                  <p className="text-xs font-bold text-slate-900 dark:text-white">
                    رفع الأوفلاين للسحابة
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    اعتماد نسخة الجهاز على حساب جوجل
                  </p>
                </div>
              </button>
            </div>

            {user && isOnline && (
              <button
                type="button"
                disabled={syncing || loadingCloud}
                onClick={() => void handleCleanCloud()}
                className="w-full flex items-center justify-between gap-3 p-3 rounded-xl border border-emerald-300 dark:border-emerald-800 bg-emerald-50/70 dark:bg-emerald-950/30 hover:bg-emerald-100/80 dark:hover:bg-emerald-950/50 text-right disabled:opacity-60"
              >
                <div className="flex items-center gap-2.5">
                  <Sparkles className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
                  <div>
                    <p className="text-xs font-bold text-emerald-950 dark:text-emerald-200">
                      تنظيف وتفريغ البيانات التجريبية وغير اللازمة في السحابة للتطوير
                    </p>
                    <p className="text-[11px] text-emerald-800 dark:text-emerald-300">
                      يزيل البيانات النموذجية والمسودات الفارغة والرسائل المقروءة مع الإبقاء على بياناتك الفعلية
                    </p>
                  </div>
                </div>
              </button>
            )}
          </div>

          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              {!localMode ? (
                <button
                  type="button"
                  onClick={async () => {
                    await onSwitchToOffline();
                    onClose();
                  }}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-amber-300 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/30 text-amber-800 dark:text-amber-300 text-xs font-semibold hover:bg-amber-100 dark:hover:bg-amber-950/60"
                >
                  <HardDrive className="w-3.5 h-3.5" />
                  تحويل الأونلاين إلى وضع الأوفلاين (حفظ على الجهاز)
                </button>
              ) : user ? (
                <button
                  type="button"
                  disabled={!isOnline}
                  onClick={() => {
                    onSwitchToOnline();
                    onClose();
                  }}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-blue-300 dark:border-blue-800 bg-blue-50 dark:bg-blue-950/30 text-blue-800 dark:text-blue-300 text-xs font-semibold hover:bg-blue-100 disabled:opacity-50"
                >
                  <Cloud className="w-3.5 h-3.5" />
                  التشغيل في وضع الأونلاين (حساب جوجل)
                </button>
              ) : (
                <span className="text-[11px] text-slate-500 dark:text-slate-400">
                  يمكنك العمل أوفلاين بحرية ثم ربط جوجل للمزامنة في أي وقت.
                </span>
              )}

              {user && (
                <button
                  type="button"
                  onClick={async () => {
                    await onSignOutGoogle();
                    onClose();
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-red-50 hover:text-red-700 dark:hover:bg-red-950/40 dark:hover:text-red-300"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  فصل حساب جوجل
                </button>
              )}
            </div>

            <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
              <div className="text-[11px] text-slate-600 dark:text-slate-400">
                عملت على ملف الـ HTML الأوفلاين؟ ارفع ملف النسخة (<code className="font-mono">.json</code>) لدمجه مع بياناتك:
              </div>
              <input
                ref={jsonInputRef}
                type="file"
                accept=".json,application/json"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  e.target.value = '';
                  if (f) void handleJsonMergeUpload(f);
                }}
              />
              <button
                type="button"
                disabled={syncing}
                onClick={() => jsonInputRef.current?.click()}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <FileJson className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
                دمج ملف أوفلاين (.json)
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
