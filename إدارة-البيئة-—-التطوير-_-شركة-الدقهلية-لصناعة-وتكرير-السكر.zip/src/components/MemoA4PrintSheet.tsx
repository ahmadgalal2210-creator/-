import { formatDateAr } from '../lib/fileParser';
import type { ItemDomain, MemoDirection } from '../types';

export interface PrintableMemoData {
  headerMode?: 'memo' | 'draft';
  title: string;
  content: string;
  domain: ItemDomain;
  direction?: MemoDirection;
  departmentName?: string;
  projectName?: string;
  updatedAt?: string;
  linkedFileNames?: string[];
}

export function MemoA4PrintSheet({ memo }: { memo: PrintableMemoData | null }) {
  if (!memo) return null;

  return (
    <div className="print-only-memo bg-white text-slate-900 p-8 min-h-[270mm]" dir="rtl">
      {/* Top-Left Company & Department Header as requested */}
      <div className="flex items-start justify-between border-b-2 border-slate-900 pb-4 mb-6">
        <div className="text-right text-xs text-slate-600 space-y-1">
          <div>التاريخ: {formatDateAr(memo.updatedAt || new Date().toISOString())}</div>
          {memo.direction && (
            <div>
              التصنيف: {memo.direction === 'incoming' ? 'وارد' : 'صادر'}
            </div>
          )}
          {memo.departmentName && <div>الجهة / الإدارة: {memo.departmentName}</div>}
          {memo.projectName && <div>المجلد: {memo.projectName}</div>}
        </div>

        <div className="text-left" dir="rtl">
          <div className="font-display text-lg font-extrabold text-slate-950">
            شركة الدقهلية لصناعة وتكرير السكر
          </div>
          <div className="font-display text-sm font-semibold text-slate-700 mt-0.5">
            {memo.headerMode === 'draft'
              ? 'إدارة البيئة — مسودة عمل'
              : 'الإدارة العامة للبيئة والسلامة المهنية'}
          </div>
        </div>
      </div>

      <h1 className="font-display text-xl font-bold text-slate-950 mb-4 text-center">
        {memo.title}
      </h1>

      <div className="text-sm leading-8 text-slate-800 whitespace-pre-wrap min-h-[160mm]">
        {memo.content}
      </div>

      {memo.linkedFileNames && memo.linkedFileNames.length > 0 && (
        <div className="mt-6 pt-4 border-t border-slate-300 text-xs text-slate-700">
          <p className="font-bold mb-1">المرفقات ({memo.linkedFileNames.length}):</p>
          <ul className="list-disc pr-5 space-y-0.5">
            {memo.linkedFileNames.map((name, i) => (
              <li key={i}>{name}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="mt-10 pt-4 border-t border-slate-200 flex items-center justify-between text-xs text-slate-600">
        <span>إدارة البيئة — السكرتارية</span>
        <span>د. أيمن عبد الحميد — مدير عام البيئة والسلامة المهنية</span>
      </div>
    </div>
  );
}
