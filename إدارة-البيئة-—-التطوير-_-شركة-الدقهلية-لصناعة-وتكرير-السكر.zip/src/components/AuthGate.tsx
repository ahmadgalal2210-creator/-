import { ArrowLeftRight, Building2, HardDrive, ShieldCheck } from 'lucide-react';

interface AuthGateProps {
  onSignIn: () => void;
  onEnterLocalMode: () => void;
  isSigningIn: boolean;
  authError: string | null;
}

export function AuthGate({
  onSignIn,
  onEnterLocalMode,
  isSigningIn,
  authError,
}: AuthGateProps) {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm p-8 space-y-6">
        <div className="flex items-start gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-400 flex items-center justify-center shrink-0">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <h1 className="font-display text-xl font-extrabold text-slate-900 dark:text-white">
              إدارة البيئة — السكرتارية
            </h1>
            <p className="text-xs font-semibold text-blue-700 dark:text-blue-400 mt-0.5">
              شركة الدقهلية لصناعة وتكرير السكر
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              د. أيمن عبد الحميد — دكتوراه في الكيمياء والسلامة المهنية
            </p>
          </div>
        </div>

        <div className="rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-4 space-y-2 text-xs text-slate-600 dark:text-slate-300">
          <p className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            مزايا المنظومة المتكاملة:
          </p>
          <ul className="list-disc pr-5 space-y-1">
            <li>مراسلات خارجية، مذكرات المصنع (صادر ووارد)، والإدارات الفرعية الأربع.</li>
            <li>رسائل الماجستير والدكتوراه في الكيمياء والسلامة المهنية بالتسلسل السريع.</li>
            <li>مذكرة الأعمال والتكليفات، المسودات، والطباعة على مقاس A4 أو التصدير إلى Word.</li>
            <li>العمل أونلاين بحساب جوجل أو أوفلاين على الجهاز مع المزامنة الثنائية في أي وقت.</li>
          </ul>
        </div>

        {authError && (
          <div className="p-3 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-xs text-red-700 dark:text-red-300">
            {authError}
          </div>
        )}

        <div className="space-y-3">
          <button
            type="button"
            disabled={isSigningIn}
            onClick={onSignIn}
            className="w-full py-3 px-4 rounded-xl bg-blue-700 hover:bg-blue-800 disabled:opacity-60 text-white text-sm font-bold flex items-center justify-center gap-2 transition-colors"
          >
            <ArrowLeftRight className="w-4 h-4" />
            <span>
              {isSigningIn
                ? 'جاري الاتصال بحساب جوجل وسحب قاعدة البيانات...'
                : 'ربط والمزامنة بحساب جوجل (أونلاين)'}
            </span>
          </button>

          <button
            type="button"
            onClick={onEnterLocalMode}
            className="w-full py-3 px-4 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 text-sm font-semibold flex items-center justify-center gap-2 transition-colors"
          >
            <HardDrive className="w-4 h-4 text-slate-600 dark:text-slate-300" />
            <span>الدخول في الوضع المحلي بدون إنترنت (أوفلاين)</span>
          </button>
        </div>
      </div>
    </div>
  );
}
