import { useRef, useState } from 'react';
import {
  CheckCircle2,
  Download,
  FileCode2,
  FileJson,
  FolderArchive,
  FolderCheck,
  FolderPlus,
  HardDriveDownload,
  RefreshCw,
  Smartphone,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import type { FolderConnectionInfo } from '../lib/folderStorageService';
import {
  downloadWorkspaceBackupJson,
  loadAutoRecoverySnapshot,
  parseWorkspaceBackupJson,
} from '../lib/localWorkspaceService';
import { buildStandaloneOfflineHtml } from '../lib/offlineHtmlExporter';
import type { WorkspaceState } from '../types';

interface OfflineDownloadModalProps {
  open: boolean;
  workspace: WorkspaceState;
  folderInfo: FolderConnectionInfo;
  onConnectNewFolder: () => Promise<void>;
  onReconnectNewFolder: () => Promise<void>;
  onDownloadNewFolderZip: () => Promise<void>;
  onDownloadDbJson: () => void;
  onImportNewFolderFiles: (files: FileList) => Promise<void>;
  onClose: () => void;
  onImportBackup: (ws: WorkspaceState) => Promise<void>;
  onOpenClearModal: () => void;
  onToast: (msg: string) => void;
}

export function OfflineDownloadModal({
  open,
  workspace,
  folderInfo,
  onConnectNewFolder,
  onReconnectNewFolder,
  onDownloadNewFolderZip,
  onDownloadDbJson,
  onImportNewFolderFiles,
  onClose,
  onImportBackup,
  onOpenClearModal,
  onToast,
}: OfflineDownloadModalProps) {
  const { canInstall, isInstalled, promptInstall } = usePWAInstall();
  const [busy, setBusy] = useState(false);
  const [installHint, setInstallHint] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);

  if (!open) return null;

  const handleDownloadOfflineHtml = async () => {
    setBusy(true);
    try {
      const html = await buildStandaloneOfflineHtml(workspace);
      const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `إدارة_البيئة_أوفلاين_${new Date().toISOString().slice(0, 10)}.html`;
      a.click();
      URL.revokeObjectURL(url);
      onToast('تم تحميل صفحة العمل الأوفلاين المطابقة للأونلاين (.html)');
    } catch (err) {
      onToast(
        err instanceof Error ? err.message : 'تعذر تجهيز ملف الصفحة الأوفلاين'
      );
    } finally {
      setBusy(false);
    }
  };

  const handleInstallPwa = async () => {
    if (canInstall) {
      const outcome = await promptInstall();
      if (outcome === 'accepted') {
        onToast('تم تثبيت «إدارة البيئة» كتطبيق مستقل على جهازك');
        return;
      }
    }
    setInstallHint(true);
  };

  const handleRestoreAutoSnapshot = async () => {
    setBusy(true);
    try {
      const snap = await loadAutoRecoverySnapshot();
      if (!snap) {
        onToast('لا توجد نسخة حماية تلقائية محفوظة بعد');
        return;
      }
      await onImportBackup(snap.workspace);
      onToast(`تم استرداد نسخة الحماية (${snap.label})`);
      onClose();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="fixed inset-0 bg-slate-950/45"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        role="dialog"
        aria-modal="true"
        className="relative z-10 w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xl max-h-[90vh] flex flex-col overflow-hidden"
      >
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <HardDriveDownload className="w-5 h-5 text-blue-700 dark:text-blue-400" />
            <div>
              <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">
                النسخ الاحتياطية
              </h2>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
            aria-label="إغلاق"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-4 overflow-y-auto">




          {/* 3. Standalone Offline HTML (Exact Online React Bundle) */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <FileCode2 className="w-5 h-5 text-emerald-700 dark:text-emerald-400 shrink-0" />
              <div>
                <h3 className="text-xs font-bold text-slate-900 dark:text-white">
                  تحميل ملف الكود
                </h3>
              </div>
            </div>
            <button
              type="button"
              disabled={busy}
              onClick={() => void handleDownloadOfflineHtml()}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-700 text-white text-xs font-semibold hover:bg-emerald-800 shrink-0 disabled:opacity-60"
            >
              <Download className="w-3.5 h-3.5" />
              {busy ? 'جاري التجهيز...' : 'تحميل'}
            </button>
          </div>

          {/* 4. JSON Backup & Restore */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center gap-2">
              <FileJson className="w-4 h-4 text-slate-700 dark:text-slate-300" />
              <h3 className="text-xs font-bold text-slate-900 dark:text-white">
                النسخ الاحتياطية
              </h3>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => {
                  downloadWorkspaceBackupJson(workspace);
                  onToast('تم تحميل النسخة الاحتياطية بنجاح');
                }}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-semibold"
              >
                <Download className="w-3.5 h-3.5" />
                النسخ الاحتياطية
              </button>

              <input
                ref={fileInputRef}
                type="file"
                accept=".json,application/json"
                className="hidden"
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  e.target.value = '';
                  if (!file) return;
                  setBusy(true);
                  try {
                    const parsed = await parseWorkspaceBackupJson(file);
                    await onImportBackup(parsed);
                    onToast('تم استرداد النسخة الاحتياطية بنجاح');
                    onClose();
                  } catch {
                    onToast('ملف النسخة الاحتياطية غير صالح');
                  } finally {
                    setBusy(false);
                  }
                }}
              />
              <button
                type="button"
                disabled={busy}
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                <Upload className="w-3.5 h-3.5" />
                استرداد نسخة احتياطية (.json)
              </button>

              <button
                type="button"
                disabled={busy}
                onClick={() => void handleRestoreAutoSnapshot()}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-blue-200 dark:border-blue-900 bg-blue-50 dark:bg-blue-950/30 text-blue-700 dark:text-blue-300 text-xs font-semibold"
              >
                استعادة آخر نسخة تلقائية
              </button>
            </div>
          </div>

          {/* 4. Clear Workspace Trigger */}
          <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <span className="text-[11px] text-slate-500 dark:text-slate-400">
              لتفريغ الملفات مع التأكيد المزدوج لحفظ قاعدة البيانات
            </span>
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenClearModal();
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-200 dark:border-red-900 text-red-700 dark:text-red-400 text-xs font-semibold hover:bg-red-50 dark:hover:bg-red-950/40"
            >
              <Trash2 className="w-3.5 h-3.5" />
              تفريغ الملفات
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
