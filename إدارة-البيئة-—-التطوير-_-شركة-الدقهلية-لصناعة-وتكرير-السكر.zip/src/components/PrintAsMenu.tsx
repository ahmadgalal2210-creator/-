import { useEffect, useRef, useState } from 'react';
import { ChevronDown, FileText, Printer } from 'lucide-react';

interface PrintAsMenuProps {
  onPrintPaperOrPdf: () => void;
  onExportWord?: () => Promise<void> | void;
  compact?: boolean;
}

export function PrintAsMenu({
  onPrintPaperOrPdf,
  onExportWord,
  compact = false,
}: PrintAsMenuProps) {
  const [open, setOpen] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDocClick = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', onDocClick);
    return () => document.removeEventListener('mousedown', onDocClick);
  }, [open]);

  return (
    <div
      ref={wrapRef}
      className="relative inline-block"
      onClick={(e) => e.stopPropagation()}
    >
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className={
          compact
            ? 'inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
            : 'inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800'
        }
      >
        <Printer className="w-3.5 h-3.5 text-slate-500" />
        <span>طباعة كـ</span>
        <ChevronDown className="w-3 h-3 text-slate-400" />
      </button>

      {open && (
        <div className="absolute left-0 mt-1.5 w-56 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-xl z-40 py-1 text-right">
          <button
            type="button"
            onClick={() => {
              setOpen(false);
              onPrintPaperOrPdf();
            }}
            className="w-full text-right px-3.5 py-2 text-xs font-semibold text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2"
          >
            <Printer className="w-3.5 h-3.5 text-blue-700 dark:text-blue-400 shrink-0" />
            <span>اختيار نوع الطابعة / حفظ PDF</span>
          </button>
          {onExportWord && (
            <button
              type="button"
              onClick={async () => {
                setOpen(false);
                await onExportWord();
              }}
              className="w-full text-right px-3.5 py-2 text-xs font-semibold text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2"
            >
              <FileText className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400 shrink-0" />
              <span>تصدير كملف Word (.docx)</span>
            </button>
          )}
        </div>
      )}
    </div>
  );
}
