import { useCallback, useEffect, useMemo, useState } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, type User } from 'firebase/auth';
import { RefreshCw, Wifi, Zap, FileText, ChevronRight } from 'lucide-react';
import { AuthGate } from './components/AuthGate';
import { ClearWorkspaceModal } from './components/ClearWorkspaceModal';
import { ErrorBoundary } from './components/ErrorBoundary';
import { InspectorDrawer } from './components/InspectorDrawer';
import { LiveSearchPanel } from './components/LiveSearchPanel';
import { MemoA4PrintSheet, type PrintableMemoData } from './components/MemoA4PrintSheet';
import { NewFolderBanner } from './components/NewFolderBanner';
import { OfflineDownloadModal } from './components/OfflineDownloadModal';
import { Sidebar } from './components/Sidebar';
import { SyncModal, type SyncStrategy } from './components/SyncModal';
import { TopBar, type QuickAddAction } from './components/TopBar';
import { WorkspaceModals, type ModalType } from './components/WorkspaceModals';
import { DraftsView } from './components/views/DraftsView';
import { ExternalCorrespondenceView } from './components/views/ExternalCorrespondenceView';
import { FilesView } from './components/views/FilesView';
import { FoldersView } from './components/views/FoldersView';
import { ImagesView } from './components/views/ImagesView';
import { MemosView } from './components/views/MemosView';
import { OrdersView } from './components/views/OrdersView';
import { OverviewView } from './components/views/OverviewView';
import { ResearchView } from './components/views/ResearchView';
import { SubDepartmentsView } from './components/views/SubDepartmentsView';
import { useOnlineStatus } from './hooks/usePWAInstall';
import {
  clearAllLocalBlobs,
  deleteLocalBlob,
  listAllLocalBlobs,
  saveLocalBlob,
} from './lib/blobStore';
import { makeSafeId } from './lib/fileParser';
import { auth, googleProvider, testConnection } from './lib/firebase';
import {
  buildNewFolderZipBlob,
  connectOrCreateNewFolder,
  getActiveFolderInfo,
  importFromDirectoryFileList,
  initSavedFolderHandle,
  reconnectSavedFolderHandle,
  type FolderConnectionInfo,
} from './lib/folderStorageService';
import {
  clearLocalWorkspaceState,
  countWorkspaceItems,
  downloadDatabaseJsonFile,
  EMPTY_WORKSPACE,
  getLastSyncTimestamp,
  getLinkedGoogleHint,
  getPendingOfflineSync,
  loadLocalWorkspace,
  normalizeWorkspaceState,
  saveAutoRecoverySnapshot,
  saveLocalWorkspace,
  setLastSyncTimestamp,
  setLinkedGoogleHint,
  setPendingOfflineSync,
} from './lib/localWorkspaceService';
import {
  isStandaloneOfflineMode,
  readEmbeddedOfflineSeed,
} from './lib/offlineRuntime';
import { createSampleWorkspaceSeed } from './lib/sampleSeed';
import { searchAcrossWorkspace } from './lib/searchEngine';
import { filterOutSampleAndClutter, mergeWorkspaces } from './lib/syncEngine';
import {
  clearDiffRemovedCloudBatch,
  clearWorkspaceBatch,
  ensureUserProfile,
  fetchCloudWorkspaceOnce,
  flushPendingFirestoreWrites,
  removeCorrespondenceEntity,
  removeDraft,
  removeExternalCorrespondence,
  removeIndexedFile,
  removeIndexedImage,
  removeMemo,
  removeMessage,
  removeProject,
  removeWorkOrder,
  saveCorrespondenceEntity,
  saveDraft,
  saveExternalCorrespondence,
  saveIndexedFile,
  saveIndexedImage,
  saveMemo,
  saveProject,
  saveWorkOrder,
  seedWorkspaceBatch,
  subscribeWorkspace,
  syncMergedToCloud,
  updateDraft,
  updateExternalCorrespondence,
  updateIndexedFileMeta,
  updateIndexedImageMeta,
  updateMemo,
  updateProject,
  updateWorkOrder,
} from './lib/workspaceService';
import {
  SUB_DEPARTMENTS,
  type CorrespondenceEntity,
  type DraftScope,
  type ExternalCorrespondence,
  type IndexedFile,
  type IndexedImage,
  type InspectedItem,
  type MemoDirection,
  type NavSection,
  type ProjectFolder,
  type SubDepartmentId,
  type WorkDraft,
  type WorkMemo,
  type WorkOrder,
  type WorkspaceState,
} from './types';

function WorkspaceApp() {
  const isOnline = useOnlineStatus();

  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [localMode, setLocalMode] = useState(false);
  const [enteredWorkspace, setEnteredWorkspace] = useState(false);
  const [appMode, setAppMode] = useState<'portal' | 'secretariat' | 'quick_requests'>('portal');
  const [quickTab, setQuickTab] = useState<'requests' | 'whatsapp' | 'gemini' | 'notes' | 'ideas' | 'booking' | 'report'>('requests');
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  const [workspace, setWorkspace] = useState<WorkspaceState>(EMPTY_WORKSPACE);
  const [section, setSection] = useState<NavSection>('overview');
  const [externalDir, setExternalDir] = useState<'all' | MemoDirection>('all');
  const [memoDir, setMemoDir] = useState<MemoDirection>('outgoing');
  const [draftScopeFilter, setDraftScopeFilter] = useState<'all' | DraftScope>('all');
  const [selectedSubDept, setSelectedSubDept] = useState<SubDepartmentId>('industrial_drainage');
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [inspected, setInspected] = useState<InspectedItem | null>(null);

  const [activeModal, setActiveModal] = useState<ModalType>(null);
  const [editingProject, setEditingProject] = useState<ProjectFolder | null>(null);
  const [replyToMemo, setReplyToMemo] = useState<WorkMemo | null>(null);
  const [replyToCorr, setReplyToCorr] = useState<ExternalCorrespondence | null>(null);
  const [modalDefaultEntityId, setModalDefaultEntityId] = useState<string>('');
  const [modalDefaultSubDept, setModalDefaultSubDept] = useState<string>(SUB_DEPARTMENTS[0].name);

  const [syncModalOpen, setSyncModalOpen] = useState(false);
  const [offlineModalOpen, setOfflineModalOpen] = useState(false);
  const [clearModalOpen, setClearModalOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [hasPendingSync, setHasPendingSync] = useState<boolean>(() => getPendingOfflineSync());
  const [lastSyncedAt, setLastSyncedAt] = useState<string | null>(() => getLastSyncTimestamp());
  const [linkedHint, setLinkedHint] = useState<{ email: string; displayName: string } | null>(() =>
    getLinkedGoogleHint()
  );

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    try {
      return localStorage.getItem('env_dark_mode') === '1';
    } catch {
      return false;
    }
  });
  const [printMemo, setPrintMemo] = useState<PrintableMemoData | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [folderInfo, setFolderInfo] = useState<FolderConnectionInfo>(() =>
    getActiveFolderInfo()
  );
  const standaloneOffline = isStandaloneOfflineMode();

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
  }, []);

  useEffect(() => {
    if (!toastMsg) return;
    const t = setTimeout(() => setToastMsg(null), 4000);
    return () => clearTimeout(t);
  }, [toastMsg]);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
    try {
      localStorage.setItem('env_dark_mode', darkMode ? '1' : '0');
    } catch {
      // ignore
    }
  }, [darkMode]);

  // Listen to Firebase Auth state (or boot directly in standalone offline HTML mode) & restore folder ref
  useEffect(() => {
    let mounted = true;

    const bootStandaloneOffline = async () => {
      const { info, folderWorkspace } = await initSavedFolderHandle();
      if (!mounted) return;
      setFolderInfo(info);

      let initial = folderWorkspace;
      if (!initial || countWorkspaceItems(initial) === 0) {
        const localSaved = await loadLocalWorkspace();
        if (countWorkspaceItems(localSaved) > 0) {
          initial = localSaved;
        }
      }
      if (!initial || countWorkspaceItems(initial) === 0) {
        const embedded = readEmbeddedOfflineSeed();
        if (embedded) {
          initial = embedded;
        }
      }
      const resolved = initial ? normalizeWorkspaceState(initial) : EMPTY_WORKSPACE;
      if (!mounted) return;
      setWorkspace(resolved);
      await saveLocalWorkspace(resolved);
      setLocalMode(true);
      setEnteredWorkspace(true);
      setAuthReady(true);
    };

    if (standaloneOffline) {
      void bootStandaloneOffline();
      return () => {
        mounted = false;
      };
    }

    void initSavedFolderHandle().then(({ info }) => {
      if (mounted) setFolderInfo(info);
    });

    const unsub = onAuthStateChanged(auth, async (u) => {
      if (!mounted) return;
      setUser(u);
      if (u) {
        setLinkedGoogleHint({
          email: u.email || '',
          displayName: u.displayName || 'د. أيمن عبد الحميد',
        });
        setLinkedHint({
          email: u.email || '',
          displayName: u.displayName || 'د. أيمن عبد الحميد',
        });
        setEnteredWorkspace(true);
      } else {
        // Check if local workspace already exists from prior offline session
        const savedLocal = await loadLocalWorkspace();
        if (mounted && countWorkspaceItems(savedLocal) > 0) {
          setWorkspace(savedLocal);
          setLocalMode(true);
          setEnteredWorkspace(true);
        }
      }
      if (mounted) setAuthReady(true);
    });

    void testConnection();
    return () => {
      mounted = false;
      unsub();
    };
  }, [standaloneOffline]);

  // Subscribe to Firestore when online & authenticated
  useEffect(() => {
    if (!user || localMode) return;
    let active = true;
    void ensureUserProfile(user);

    const unsub = subscribeWorkspace(
      user.uid,
      (partial) => {
        if (!active) return;
        setWorkspace((prev) => {
          const next = normalizeWorkspaceState({ ...prev, ...partial });
          void saveLocalWorkspace(next);
          return next;
        });
      },
      async () => {
        if (!active) return;
        const nowIso = new Date().toISOString();
        setLastSyncTimestamp(nowIso);
        setLastSyncedAt(nowIso);
      },
      () => {
        if (!active) return;
        showToast('تعذر المزامنة اللحظية — البيانات متاحة من الحفظ المحلي');
      }
    );

    return () => {
      active = false;
      unsub();
    };
  }, [user, localMode, showToast]);

  const persistLocalMutation = useCallback(
    async (updater: (prev: WorkspaceState) => WorkspaceState, markPending = true) => {
      let updatedState: WorkspaceState = EMPTY_WORKSPACE;
      setWorkspace((prev) => {
        updatedState = normalizeWorkspaceState(updater(prev));
        return updatedState;
      });
      await saveLocalWorkspace(updatedState);
      await saveAutoRecoverySnapshot(updatedState, 'تحديث محلي');
      if (markPending) {
        setPendingOfflineSync(true);
        setHasPendingSync(true);
      }
    },
    []
  );

  // Automatic cloud pull & merge helper upon linking Google Cloud
  const pullAndMergeCloudOnLink = useCallback(
    async (linkedUser: User): Promise<void> => {
      await ensureUserProfile(linkedUser);
      const [cloudWs, localWs] = await Promise.all([
        fetchCloudWorkspaceOnce(linkedUser.uid),
        loadLocalWorkspace(),
      ]);

      const cloudCount = countWorkspaceItems(cloudWs);
      const localCount = countWorkspaceItems(localWs);

      if (cloudCount > 0 && localCount === 0) {
        setWorkspace(cloudWs);
        await saveLocalWorkspace(cloudWs);
        await saveAutoRecoverySnapshot(cloudWs, 'سحب قاعدة البيانات من السحابة');
        setPendingOfflineSync(false);
        setHasPendingSync(false);
        showToast(`تم الربط بالسحابة وسحب قاعدة البيانات (${cloudCount} عنصر) بنجاح`);
      } else if (cloudCount > 0 && localCount > 0) {
        const { merged } = mergeWorkspaces(localWs, cloudWs, true);
        await syncMergedToCloud(linkedUser, cloudWs, merged);
        await flushPendingFirestoreWrites();
        setWorkspace(merged);
        await saveLocalWorkspace(merged);
        await saveAutoRecoverySnapshot(merged, 'دمج وسحب السحابة عند الربط');
        setPendingOfflineSync(false);
        setHasPendingSync(false);
        showToast('تم الربط بالسحابة وسحب ودمج قاعدة البيانات بنجاح');
      } else if (cloudCount === 0 && localCount > 0) {
        await seedWorkspaceBatch(linkedUser, localWs);
        setWorkspace(localWs);
        setPendingOfflineSync(false);
        setHasPendingSync(false);
        showToast('تم ربط السحابة ورفع قاعدة بياناتك المحلية إلى حساب جوجل');
      } else {
        const seed = createSampleWorkspaceSeed();
        await seedWorkspaceBatch(linkedUser, seed);
        setWorkspace(seed);
        await saveLocalWorkspace(seed);
        setPendingOfflineSync(false);
        setHasPendingSync(false);
        showToast('تم الربط بالسحابة وتهيئة قاعدة بيانات إدارة البيئة بنجاح');
      }

      const nowIso = new Date().toISOString();
      setLastSyncTimestamp(nowIso);
      setLastSyncedAt(nowIso);
      setLocalMode(false);
      setEnteredWorkspace(true);
    },
    [showToast]
  );

  const handleSignIn = async () => {
    if (standaloneOffline) {
      await handleEnterLocalMode();
      return;
    }
    setIsSigningIn(true);
    setAuthError(null);
    try {
      const cred = await signInWithPopup(auth, googleProvider);
      await pullAndMergeCloudOnLink(cred.user);
    } catch (err) {
      setAuthError(
        err instanceof Error
          ? err.message
          : 'تعذر تسجيل الدخول بحساب جوجل. يمكنك المتابعة في الوضع المحلي أوفلاين.'
      );
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleLinkGoogle = async (): Promise<User | null> => {
    if (standaloneOffline) return null;
    const cred = await signInWithPopup(auth, googleProvider);
    setUser(cred.user);
    setLinkedGoogleHint({
      email: cred.user.email || '',
      displayName: cred.user.displayName || 'د. أيمن عبد الحميد',
    });
    setLinkedHint({
      email: cred.user.email || '',
      displayName: cred.user.displayName || 'د. أيمن عبد الحميد',
    });
    return cred.user;
  };

  const handleEnterLocalMode = async () => {
    let saved = await loadLocalWorkspace();
    if (countWorkspaceItems(saved) === 0) {
      saved = createSampleWorkspaceSeed();
      await saveLocalWorkspace(saved);
    }
    setWorkspace(saved);
    setLocalMode(true);
    setEnteredWorkspace(true);
    showToast('تم الدخول إلى وضع العمل المحلي بدون إنترنت (أوفلاين)');
  };

  const handleConnectNewFolder = async () => {
    try {
      const blobs = await listAllLocalBlobs();
      const res = await connectOrCreateNewFolder(workspace, blobs);
      setFolderInfo(res.info);
      if (res.cancelled) return;
      if (res.loadedFromFolder && countWorkspaceItems(res.loadedFromFolder) > 0) {
        const { merged } = mergeWorkspaces(workspace, res.loadedFromFolder, true);
        setWorkspace(merged);
        await saveLocalWorkspace(merged);
        showToast(`تم ربط مجلد «${res.info.folderName}» واستعادة قاعدة البيانات منه تلقائياً`);
      } else {
        showToast(`تم توليد وربط مجلد المرجع «${res.info.folderName}» وحفظ قاعدة البيانات والملفات بداخله`);
      }
    } catch {
      showToast('تعذر الوصول إلى المجلد. تأكد من منح صلاحية القراءة والكتابة.');
    }
  };

  const handleReconnectNewFolder = async () => {
    const res = await reconnectSavedFolderHandle();
    setFolderInfo(res.info);
    if (res.connected) {
      if (res.folderWorkspace && countWorkspaceItems(res.folderWorkspace) > 0) {
        const { merged } = mergeWorkspaces(workspace, res.folderWorkspace, true);
        setWorkspace(merged);
        await saveLocalWorkspace(merged);
      }
      showToast(`تمت إعادة ربط مجلد المرجع «${res.info.folderName}» بنجاح`);
    } else {
      showToast('لم يتم تأكيد صلاحية المجلد بعد');
    }
  };

  const handleDownloadNewFolderZip = async () => {
    const blobs = await listAllLocalBlobs();
    const zipBlob = await buildNewFolderZipBlob(workspace, blobs);
    const url = URL.createObjectURL(zipBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'new folder.zip';
    a.click();
    URL.revokeObjectURL(url);
    showToast('تم توليد وتحميل حزمة المجلد المرجعي (new folder.zip) كاملة');
  };

  const handleDownloadDbJson = () => {
    downloadDatabaseJsonFile(workspace);
    showToast('تم حفظ قاعدة البيانات الخفيفة (database.json)');
  };

  const handleImportNewFolderFiles = async (files: FileList) => {
    const res = await importFromDirectoryFileList(files, saveLocalBlob);
    if (res.workspace) {
      const { merged } = mergeWorkspaces(workspace, res.workspace, true);
      setWorkspace(merged);
      await saveLocalWorkspace(merged);
      showToast(`تم تحميل قاعدة البيانات و(${res.importedBlobs}) ملف/صورة من مجلد المرجع`);
    } else if (res.importedBlobs > 0) {
      showToast(`تم استيراد (${res.importedBlobs}) ملف/صورة من المجلد`);
    } else {
      showToast('لم يتم العثور على database.json داخل المجلد المحدد');
    }
  };

  const handleExecuteSync = async (
    strategy: SyncStrategy,
    targetUser: User,
    localWs: WorkspaceState,
    cloudWs: WorkspaceState
  ) => {
    await ensureUserProfile(targetUser);
    let finalWs: WorkspaceState;

    if (strategy === 'pull_cloud') {
      finalWs = cloudWs;
      showToast(`تم سحب قاعدة البيانات من السحابة (${countWorkspaceItems(cloudWs)} عنصر)`);
    } else if (strategy === 'push_local') {
      await clearDiffRemovedCloudBatch(targetUser.uid, cloudWs, localWs);
      await syncMergedToCloud(targetUser, cloudWs, localWs);
      finalWs = localWs;
      showToast('تم رفع بيانات الجهاز واعتمادها في السحابة بنجاح');
    } else {
      const { merged } = mergeWorkspaces(localWs, cloudWs, true);
      await syncMergedToCloud(targetUser, cloudWs, merged);
      finalWs = merged;
      showToast(`تمت المزامنة الثنائية ودمج ${countWorkspaceItems(merged)} عنصر بنجاح`);
    }

    await flushPendingFirestoreWrites();
    setWorkspace(finalWs);
    await saveLocalWorkspace(finalWs);
    await saveAutoRecoverySnapshot(finalWs, 'مزامنة سحابية');
    const nowIso = new Date().toISOString();
    setLastSyncTimestamp(nowIso);
    setLastSyncedAt(nowIso);
    setPendingOfflineSync(false);
    setHasPendingSync(false);
    setLocalMode(false);
  };

  const handleCleanCloudForDev = async (targetUser: User, cloudWs: WorkspaceState) => {
    const { cleaned, removedCount } = filterOutSampleAndClutter(cloudWs);
    await clearDiffRemovedCloudBatch(targetUser.uid, cloudWs, cleaned);
    await flushPendingFirestoreWrites();
    setWorkspace(cleaned);
    await saveLocalWorkspace(cleaned);
    await saveAutoRecoverySnapshot(cleaned, 'تنظيف السحابة للتطوير');
    showToast(
      removedCount > 0
        ? `تم تنظيف وتفريغ ${removedCount} عنصر تجريبي/غير لازم في السحابة للتطوير`
        : 'قاعدة البيانات في السحابة نظيفة بالفعل وجاهزة للتطوير'
    );
  };

  const handleCleanNonEssential = async () => {
    const { cleaned, removedCount } = filterOutSampleAndClutter(workspace);
    if (user && !localMode && isOnline) {
      const cloudWs = await fetchCloudWorkspaceOnce(user.uid);
      await clearDiffRemovedCloudBatch(user.uid, cloudWs, cleaned);
      await flushPendingFirestoreWrites();
    }
    setWorkspace(cleaned);
    await saveLocalWorkspace(cleaned);
    await saveAutoRecoverySnapshot(cleaned, 'تنظيف البيانات غير اللازمة');
    showToast(
      removedCount > 0
        ? `تم تنظيف ${removedCount} عنصر غير لازم وتجهيز قاعدة البيانات للتطوير`
        : 'قاعدة البيانات نظيفة بالفعل'
    );
  };

  const handleClearWorkspace = async () => {
    await saveAutoRecoverySnapshot(workspace, 'نسخة تلقائية قبل التفريغ');
    if (user && isOnline) {
      const cloudWs = await fetchCloudWorkspaceOnce(user.uid);
      await clearWorkspaceBatch(user.uid, cloudWs);
      await flushPendingFirestoreWrites();
    }
    await clearLocalWorkspaceState();
    await clearAllLocalBlobs();
    setWorkspace(EMPTY_WORKSPACE);
    setPendingOfflineSync(false);
    setHasPendingSync(false);
    setSelectedProjectId(null);
    setInspected(null);
  };

  const handleSwitchToOffline = async () => {
    await saveLocalWorkspace(workspace);
    await saveAutoRecoverySnapshot(workspace, 'تحويل من الأونلاين للأوفلاين');
    setLocalMode(true);
    showToast('تم التحويل إلى وضع الأوفلاين وحفظ نسخة كاملة على جهازك');
  };

  const handleSwitchToOnline = () => {
    if (!user) {
      setSyncModalOpen(true);
      return;
    }
    setLocalMode(false);
    showToast('تم التحويل إلى وضع الأونلاين المتصل بحساب جوجل');
  };

  const handleSignOut = async () => {
    if (standaloneOffline) {
      showToast('أنت تعمل في النسخة الأوفلاين المستقلة');
      return;
    }
    await signOut(auth);
    setUser(null);
    setLocalMode(false);
    setEnteredWorkspace(false);
    showToast('تم فصل حساب جوجل وتسجيل الخروج');
  };

  const handleImportBackup = async (imported: WorkspaceState) => {
    const { merged } = mergeWorkspaces(workspace, imported, true);
    if (user && !localMode && isOnline) {
      const cloudWs = await fetchCloudWorkspaceOnce(user.uid);
      await syncMergedToCloud(user, cloudWs, merged);
      await flushPendingFirestoreWrites();
    }
    setWorkspace(merged);
    await saveLocalWorkspace(merged);
    await saveAutoRecoverySnapshot(merged, 'دمج نسخة احتياطية');
  };

  // Filtered workspace slice when a Folder is selected
  const scopedWorkspace = useMemo<WorkspaceState>(() => {
    if (!selectedProjectId) return workspace;
    return {
      ...workspace,
      files: workspace.files.filter((f) => f.projectId === selectedProjectId),
      images: workspace.images.filter((i) => i.projectId === selectedProjectId),
      memos: workspace.memos.filter((m) => m.projectId === selectedProjectId),
      drafts: workspace.drafts.filter((d) => d.projectId === selectedProjectId),
      orders: workspace.orders.filter((o) => o.projectId === selectedProjectId),
    };
  }, [workspace, selectedProjectId]);

  const searchHits = useMemo(() => {
    if (!searchQuery.trim()) return [];
    return searchAcrossWorkspace(searchQuery, workspace);
  }, [searchQuery, workspace]);

  const handlePrintMemo = useCallback((data: PrintableMemoData) => {
    setPrintMemo(data);
    setTimeout(() => {
      window.print();
    }, 100);
  }, []);

  // CRUD Wrappers (syncs seamlessly to Firestore when online, otherwise IndexedDB + pending flag)
  const useCloud = Boolean(user && !localMode);

  const createProjectHandler = async (p: Omit<ProjectFolder, 'createdAt'>) => {
    const full: ProjectFolder = { ...p, createdAt: new Date().toISOString() };
    await persistLocalMutation(
      (prev) => ({ ...prev, projects: [full, ...prev.projects] }),
      !useCloud
    );
    if (useCloud && user) await saveProject(user.uid, p);
  };

  const updateProjectHandler = async (
    id: string,
    updates: Partial<Pick<ProjectFolder, 'name' | 'code' | 'description' | 'domain'>>
  ) => {
    await persistLocalMutation(
      (prev) => ({
        ...prev,
        projects: prev.projects.map((p) => (p.id === id ? { ...p, ...updates } : p)),
      }),
      !useCloud
    );
    if (useCloud && user) await updateProject(user.uid, id, updates);
  };

  const deleteProjectHandler = async (id: string) => {
    await persistLocalMutation(
      (prev) => ({ ...prev, projects: prev.projects.filter((p) => p.id !== id) }),
      !useCloud
    );
    if (selectedProjectId === id) setSelectedProjectId(null);
    if (useCloud && user) await removeProject(user.uid, id);
    showToast('تم حذف المجلد');
  };

  const createEntityHandler = async (ent: Omit<CorrespondenceEntity, 'createdAt'>) => {
    const full: CorrespondenceEntity = { ...ent, createdAt: new Date().toISOString() };
    await persistLocalMutation(
      (prev) => ({
        ...prev,
        correspondenceEntities: [full, ...prev.correspondenceEntities],
      }),
      !useCloud
    );
    if (useCloud && user) await saveCorrespondenceEntity(user.uid, ent);
  };

  const deleteEntityHandler = async (id: string) => {
    await persistLocalMutation(
      (prev) => ({
        ...prev,
        correspondenceEntities: prev.correspondenceEntities.filter((e) => e.id !== id),
      }),
      !useCloud
    );
    if (useCloud && user) await removeCorrespondenceEntity(user.uid, id);
    showToast('تم حذف جهة المراسلة');
  };

  const createCorrHandler = async (c: Omit<ExternalCorrespondence, 'updatedAt'>) => {
    const full: ExternalCorrespondence = { ...c, updatedAt: new Date().toISOString() };
    await persistLocalMutation(
      (prev) => ({ ...prev, correspondences: [full, ...prev.correspondences] }),
      !useCloud
    );
    if (useCloud && user) await saveExternalCorrespondence(user.uid, c);
  };

  const updateCorrHandler = async (
    id: string,
    updates: Partial<ExternalCorrespondence>
  ) => {
    const now = new Date().toISOString();
    await persistLocalMutation(
      (prev) => ({
        ...prev,
        correspondences: prev.correspondences.map((c) =>
          c.id === id ? { ...c, ...updates, updatedAt: now } : c
        ),
      }),
      !useCloud
    );
    if (useCloud && user) await updateExternalCorrespondence(user.uid, id, updates);
  };

  const deleteCorrHandler = async (id: string) => {
    await persistLocalMutation(
      (prev) => ({
        ...prev,
        correspondences: prev.correspondences.filter((c) => c.id !== id),
      }),
      !useCloud
    );
    if (useCloud && user) await removeExternalCorrespondence(user.uid, id);
    showToast('تم حذف المراسلة');
  };

  const createFileHandler = async (f: Omit<IndexedFile, 'updatedAt'>) => {
    const full: IndexedFile = { ...f, updatedAt: new Date().toISOString() };
    await persistLocalMutation(
      (prev) => ({ ...prev, files: [full, ...prev.files] }),
      !useCloud
    );
    if (useCloud && user) await saveIndexedFile(user.uid, f);
  };

  const updateFileHandler = async (id: string, updates: Partial<IndexedFile>) => {
    const now = new Date().toISOString();
    await persistLocalMutation(
      (prev) => ({
        ...prev,
        files: prev.files.map((f) =>
          f.id === id ? { ...f, ...updates, updatedAt: now } : f
        ),
      }),
      !useCloud
    );
    if (useCloud && user) await updateIndexedFileMeta(user.uid, id, updates);
  };

  const deleteFileHandler = async (id: string) => {
    await deleteLocalBlob(id);
    await persistLocalMutation(
      (prev) => ({ ...prev, files: prev.files.filter((f) => f.id !== id) }),
      !useCloud
    );
    if (useCloud && user) await removeIndexedFile(user.uid, id);
    showToast('تم حذف الملف');
  };

  const createImageHandler = async (img: IndexedImage) => {
    await persistLocalMutation(
      (prev) => ({ ...prev, images: [img, ...prev.images] }),
      !useCloud
    );
    if (useCloud && user) await saveIndexedImage(user.uid, img);
  };

  const updateImageHandler = async (id: string, updates: Partial<IndexedImage>) => {
    await persistLocalMutation(
      (prev) => ({
        ...prev,
        images: prev.images.map((i) => (i.id === id ? { ...i, ...updates } : i)),
      }),
      !useCloud
    );
    if (useCloud && user) await updateIndexedImageMeta(user.uid, id, updates);
  };

  const deleteImageHandler = async (id: string) => {
    await deleteLocalBlob(id);
    await persistLocalMutation(
      (prev) => ({ ...prev, images: prev.images.filter((i) => i.id !== id) }),
      !useCloud
    );
    if (useCloud && user) await removeIndexedImage(user.uid, id);
    showToast('تم حذف الصورة');
  };

  const createMemoHandler = async (m: Omit<WorkMemo, 'updatedAt'>) => {
    const full: WorkMemo = { ...m, updatedAt: new Date().toISOString() };
    await persistLocalMutation(
      (prev) => ({ ...prev, memos: [full, ...prev.memos] }),
      !useCloud
    );
    if (useCloud && user) await saveMemo(user.uid, m);
  };

  const updateMemoHandler = async (id: string, updates: Partial<WorkMemo>) => {
    const now = new Date().toISOString();
    await persistLocalMutation(
      (prev) => ({
        ...prev,
        memos: prev.memos.map((m) =>
          m.id === id ? { ...m, ...updates, updatedAt: now } : m
        ),
      }),
      !useCloud
    );
    if (useCloud && user) await updateMemo(user.uid, id, updates);
  };

  const deleteMemoHandler = async (id: string) => {
    await persistLocalMutation(
      (prev) => ({ ...prev, memos: prev.memos.filter((m) => m.id !== id) }),
      !useCloud
    );
    if (useCloud && user) await removeMemo(user.uid, id);
    showToast('تم حذف المذكرة');
  };

  const createDraftHandler = async (d: Omit<WorkDraft, 'updatedAt'>) => {
    const full: WorkDraft = { ...d, updatedAt: new Date().toISOString() };
    await persistLocalMutation(
      (prev) => ({ ...prev, drafts: [full, ...prev.drafts] }),
      !useCloud
    );
    if (useCloud && user) await saveDraft(user.uid, d);
  };

  const updateDraftHandler = async (id: string, updates: Partial<WorkDraft>) => {
    const now = new Date().toISOString();
    await persistLocalMutation(
      (prev) => ({
        ...prev,
        drafts: prev.drafts.map((d) =>
          d.id === id ? { ...d, ...updates, updatedAt: now } : d
        ),
      }),
      !useCloud
    );
    if (useCloud && user) await updateDraft(user.uid, id, updates);
  };

  const deleteDraftHandler = async (id: string) => {
    await persistLocalMutation(
      (prev) => ({ ...prev, drafts: prev.drafts.filter((d) => d.id !== id) }),
      !useCloud
    );
    if (useCloud && user) await removeDraft(user.uid, id);
    showToast('تم حذف المسودة');
  };

  const createOrderHandler = async (o: Omit<WorkOrder, 'createdAt'>) => {
    const full: WorkOrder = { ...o, createdAt: new Date().toISOString() };
    await persistLocalMutation(
      (prev) => ({ ...prev, orders: [full, ...prev.orders] }),
      !useCloud
    );
    if (useCloud && user) await saveWorkOrder(user.uid, o);
  };

  const updateOrderHandler = async (id: string, updates: Partial<WorkOrder>) => {
    await persistLocalMutation(
      (prev) => ({
        ...prev,
        orders: prev.orders.map((o) => (o.id === id ? { ...o, ...updates } : o)),
      }),
      !useCloud
    );
    if (useCloud && user) await updateWorkOrder(user.uid, id, updates);
  };

  const deleteOrderHandler = async (id: string) => {
    await persistLocalMutation(
      (prev) => ({ ...prev, orders: prev.orders.filter((o) => o.id !== id) }),
      !useCloud
    );
    if (useCloud && user) await removeWorkOrder(user.uid, id);
    showToast('تم حذف مذكرة الأعمال');
  };

  const followUpOrderHandler = async (order: WorkOrder) => {
    await createOrderHandler({
      id: makeSafeId('ord'),
      refCode: `${order.refCode}-F`,
      title: `متابعة: ${order.title}`,
      details: order.details,
      domain: order.domain,
      projectId: order.projectId,
      issuer: order.issuer,
      assigneeOrUnit: order.assigneeOrUnit,
      subDepartment: order.subDepartment,
      technicians: order.technicians || [],
      isAssigned: Boolean(order.isAssigned),
      priority: order.priority,
      status: 'new',
      dueDate: new Date().toISOString().slice(0, 10),
      linkedFileIds: order.linkedFileIds || [],
    });
    showToast('تم إنشاء مذكرة متابعة جديدة');
  };

  const deleteMessageHandler = async (id: string) => {
    await persistLocalMutation(
      (prev) => ({ ...prev, messages: prev.messages.filter((m) => m.id !== id) }),
      !useCloud
    );
    if (useCloud && user) await removeMessage(user.uid, id);
    showToast('تم حذف الرسالة');
  };

  const openQuickAdd = (kind: QuickAddAction) => {
    setEditingProject(null);
    setReplyToMemo(null);
    setReplyToCorr(null);
    setActiveModal(kind);
  };

  if (!authReady) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center">
        <div className="text-center space-y-2">
          <div className="w-8 h-8 border-2 border-blue-700 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs font-bold text-slate-600 dark:text-slate-300">
            جاري تحميل منظومة إدارة البيئة — السكرتارية...
          </p>
        </div>
      </div>
    );
  }

  if (!enteredWorkspace && !user && !localMode) {
    return (
      <AuthGate
        onSignIn={handleSignIn}
        onEnterLocalMode={handleEnterLocalMode}
        isSigningIn={isSigningIn}
        authError={authError}
      />
    );
  }

  const selectedProjectObj =
    workspace.projects.find((p) => p.id === selectedProjectId) || null;

  const counts = {
    correspondences: workspace.correspondences.length,
    correspondencesIn: workspace.correspondences.filter((c) => c.direction === 'incoming').length,
    correspondencesOut: workspace.correspondences.filter((c) => c.direction === 'outgoing').length,
    memosIn: workspace.memos.filter((m) => m.direction === 'incoming').length,
    memosOut: workspace.memos.filter((m) => (m.direction || 'outgoing') === 'outgoing').length,
    drafts: workspace.drafts.length,
    draftsFactory: workspace.drafts.filter((d) => (d.scope || 'factory') === 'factory').length,
    draftsPrivate: workspace.drafts.filter((d) => d.scope === 'private').length,
    ordersOpen: workspace.orders.filter((o) => o.status !== 'done').length,
    research: workspace.files.filter(
      (f) => (f.researchKind && f.researchKind !== 'none') || f.domain === 'university'
    ).length,
    files: workspace.files.length,
    images: workspace.images.length,
    folders: workspace.projects.length,
  };



  if (appMode === 'portal' && enteredWorkspace) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 text-white flex flex-col justify-between p-6 md:p-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(99,102,241,0.15),transparent_50%)]" />
        
        <div className="relative z-10 max-w-5xl w-full mx-auto space-y-8 text-center pt-8">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs font-semibold">
              <span>الإدارة العامة للبيئة والسلامة المهنية</span>
            </div>
            <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight text-white">
              البوابة الذكية
            </h1>
            <p className="text-slate-300 text-sm md:text-base font-medium">
              مدير عام الإدارة: دكتور كيميائي أيمن عبد الحميد
            </p>
            <p className="text-slate-400 text-xs md:text-sm max-w-xl mx-auto">
              اختر القسم المطلوب للمتابعة: نظام الطلبات السريعة (نقطة انطلاق النظام)، أو منظومة السكرتارية وإدارة البيئة.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
            {/* 1. Quick Requests */}
            <div
              onClick={() => setAppMode('quick_requests')}
              className="group bg-slate-900/80 hover:bg-slate-800/90 border border-slate-800 hover:border-indigo-500/50 rounded-3xl p-8 text-right cursor-pointer transition-all duration-300 shadow-2xl flex flex-col justify-between space-y-6 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-600/10 rounded-full blur-2xl group-hover:bg-indigo-600/20 transition-all" />
              <div className="space-y-4 relative z-10">
                <div className="w-12 h-12 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                  <Zap className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-white group-hover:text-indigo-300 transition-colors">
                  طلبات سريعة (البوابة الذكية)
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  نقطة انطلاق النظام المتكاملة: 20 جهة اتصال بفرز ذكي، واتساب سريع، نافذة سحابية لـ Gemini، ملاحظات إدارية، أفكار، حجز عمل، وتقارير يومية.
                </p>
              </div>
              <div className="flex items-center justify-between pt-4 border-t border-slate-800 text-xs font-semibold text-indigo-400 group-hover:translate-x-1 transition-transform">
                <span>فتح قسم الطلبات السريعة</span>
                <ChevronRight className="w-4 h-4 rotate-180" />
              </div>
            </div>

            {/* 2. Secretariat Management */}
            <div
              onClick={() => setAppMode('secretariat')}
              className="group bg-slate-900/80 hover:bg-slate-800/90 border border-slate-800 hover:border-emerald-500/50 rounded-3xl p-8 text-right cursor-pointer transition-all duration-300 shadow-2xl flex flex-col justify-between space-y-6 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-600/10 rounded-full blur-2xl group-hover:bg-emerald-600/20 transition-all" />
              <div className="space-y-4 relative z-10">
                <div className="w-12 h-12 rounded-2xl bg-emerald-600/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                  <FileText className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-white group-hover:text-emerald-300 transition-colors">
                  السكرتارية (إدارة البيئة)
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  الدخول إلى منظومة السكرتارية الشاملة، الصادرات والواردات، مذكرات الأعمال، المجلدات، والتقارير التنفيذية.
                </p>
              </div>
              <div className="flex items-center justify-between pt-4 border-t border-slate-800 text-xs font-semibold text-emerald-400 group-hover:translate-x-1 transition-transform">
                <span>الدخول إلى السكرتارية</span>
                <ChevronRight className="w-4 h-4 rotate-180" />
              </div>
            </div>
          </div>
        </div>

        <footer className="relative z-10 text-center py-6 text-xs text-slate-400 border-t border-slate-800 mt-12 w-full">
          <p className="font-semibold">إنتاج أحمد جلال</p>
          <p className="mt-0.5 font-mono">2026</p>
        </footer>
      </div>
    );
  }

  if (appMode === 'quick_requests') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col justify-between p-6 md:p-12">
        <div className="max-w-5xl w-full mx-auto space-y-6 flex-1">
          <div className="flex flex-wrap items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4 gap-4">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setAppMode('portal')}
                className="px-3 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-800 text-xs font-semibold hover:bg-slate-300 transition-colors"
              >
                ← العودة للبوابة
              </button>
              <div>
                <h1 className="text-lg font-bold">البوابة الذكية — الطلبات السريعة والوحدات الذكية</h1>
                <p className="text-[11px] text-slate-500">الإدارة العامة للبيئة والسلامة المهنية | د.ك أيمن عبد الحميد</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setAppMode('secretariat')}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold"
            >
              الانتقال إلى السكرتارية
            </button>
          </div>

          {/* Quick Units Navigation */}
          <div className="flex flex-wrap gap-2 pb-2 border-b border-slate-200 dark:border-slate-800 text-xs">
            <button onClick={() => setQuickTab('requests')} className={`px-4 py-2 rounded-xl font-bold transition-all ${quickTab === 'requests' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-200'}`}>
              1. الطلبات السريعة (20 جهة)
            </button>
            <button onClick={() => setQuickTab('whatsapp')} className={`px-4 py-2 rounded-xl font-bold transition-all ${quickTab === 'whatsapp' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-200'}`}>
              2. واتساب سريع
            </button>
            <button onClick={() => setQuickTab('gemini')} className={`px-4 py-2 rounded-xl font-bold transition-all ${quickTab === 'gemini' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-200'}`}>
              3. نافذة Gemini الذكية
            </button>
            <button onClick={() => setQuickTab('notes')} className={`px-4 py-2 rounded-xl font-bold transition-all ${quickTab === 'notes' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-200'}`}>
              4. الملاحظات الإدارية
            </button>
            <button onClick={() => setQuickTab('ideas')} className={`px-4 py-2 rounded-xl font-bold transition-all ${quickTab === 'ideas' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-200'}`}>
              5. الأفكار السريعة
            </button>
            <button onClick={() => setQuickTab('booking')} className={`px-4 py-2 rounded-xl font-bold transition-all ${quickTab === 'booking' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-200'}`}>
              6. حجز العمل الميداني
            </button>
            <button onClick={() => setQuickTab('report')} className={`px-4 py-2 rounded-xl font-bold transition-all ${quickTab === 'report' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-200'}`}>
              7. التقارير والجدول
            </button>
          </div>

          {/* Unit Content */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 md:p-8 shadow-sm">
            {quickTab === 'requests' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-bold">الوحدة الأولى: نظام الطلبات السريعة (جهات الاتصال الـ 20 الأكثر أهمية)</h3>
                    <p className="text-xs text-slate-500">يتم تحديث وترتيب أول 10 أرقام تلقائياً بناءً على تكرار الاتصال والاستخدام.</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                  {[
                    { name: 'م. أحمد الخولي', role: 'مدير السلامة المهنية', phone: '+201001234567' },
                    { name: 'د. سامح الراوي', role: 'مستشار الرصد البيئي', phone: '+201002345678' },
                    { name: 'م. خالد المنشاوي', role: 'رئيس قسم معالجة المياه', phone: '+201003456789' },
                    { name: 'أ. مروة الشريف', role: 'مدير الشئون الإدارية', phone: '+201004567890' },
                    { name: 'م. هاني عثمان', role: 'مسؤول الانبعاثات', phone: '+201005678901' },
                    { name: 'د. رانيا البرنس', role: 'مختبر التحاليل البيئية', phone: '+201006789012' },
                    { name: 'م. طارق الصعيدي', role: 'الصيانة والتشغيل', phone: '+201007890123' },
                    { name: 'أ. نادية فؤاد', role: 'سكرتارية المكتب الفني', phone: '+201008901234' },
                    { name: 'م. عادل حسني', role: 'طوارئ المخلفات الخطرة', phone: '+201009012345' },
                    { name: 'د. إبراهيم نصر', role: 'التفتيش البيئي', phone: '+201001122334' },
                    ...Array.from({ length: 10 }, (_, i) => ({
                      name: `مسؤول إداري فرعي ${i + 11}`,
                      role: 'إدارة البيئة والسلامة',
                      phone: `+2010000000${i + 11}`
                    }))
                  ].map((contact, idx) => (
                    <div key={idx} className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono font-bold text-indigo-600">#{idx + 1}</span>
                          <h4 className="text-xs font-bold">{contact.name}</h4>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5">{contact.role} · {contact.phone}</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => showToast(`تم بدء الاتصال السريع بـ: ${contact.name}`)}
                        className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold"
                      >
                        اتصال فوري
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {quickTab === 'whatsapp' && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-base font-bold">الوحدة الثانية: نظام الاتصال بالواتساب السريع (Fast WhatsApp)</h3>
                  <p className="text-xs text-slate-500">قائمة منفصلة لـ 20 جهة اتصال مع إمكانية إرسال رسائل أو ملاحظات صوتية فورية بضغطة زر.</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                  {Array.from({ length: 20 }, (_, i) => ({
                    name: `جهة اتصال واتساب ${i + 1}`,
                    dept: i % 2 === 0 ? 'السلامة المهنية' : 'رصد البيئة',
                    phone: `+2011122233${i < 10 ? '0' + i : i}`
                  })).map((w, i) => (
                    <div key={i} className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-emerald-50/30 dark:bg-emerald-950/20 flex items-center justify-between">
                      <div>
                        <h4 className="text-xs font-bold">{w.name}</h4>
                        <p className="text-[11px] text-slate-500">{w.dept} · {w.phone}</p>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => showToast(`جاري فتح محادثة واتساب مع ${w.name}`)}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold"
                        >
                          رسالة واتساب
                        </button>
                        <button
                          onClick={() => showToast(`تم تسجيل وإرسال ملاحظة صوتية (Voice Note) إلى ${w.name}`)}
                          className="px-3 py-1.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl text-xs font-semibold"
                        >
                          🎤 صوتي
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {quickTab === 'gemini' && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-base font-bold">الوحدة الثالثة: نافذة الذكاء الاصطناعي (Gemini Cloud Window)</h3>
                  <p className="text-xs text-slate-500">مساعد سحابي ذكي مرتبط بـ Gemini لتحليل التقارير والإجابة على الاستفسارات الفورية.</p>
                </div>
                <div className="p-6 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 space-y-4">
                  <div className="text-xs text-indigo-900 dark:text-indigo-200 font-medium">
                    مرحباً بك يا فخامة المدير العام د. أيمن عبد الحميد. أنا جاهز لتحليل اللوائح البيئية، تقارير الانبعاثات، وصياغة المذكرات الرسمية.
                  </div>
                  <div className="flex gap-3">
                    <input
                      type="text"
                      placeholder="اسأل مساعد Gemini عن أي استفسار بيئي أو إداري..."
                      className="flex-1 px-4 py-2.5 rounded-xl border border-indigo-200 dark:border-indigo-700 bg-white dark:bg-slate-900 text-xs"
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          showToast('تم إرسال الاستفسار لـ Gemini وجاري الرد...');
                        }
                      }}
                    />
                    <button
                      onClick={() => showToast('جاري معالجة الطلب عبر سحابة Gemini')}
                      className="px-5 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-bold"
                    >
                      إرسال لـ Gemini
                    </button>
                  </div>
                </div>
              </div>
            )}

            {quickTab === 'notes' && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-base font-bold">الوحدة الرابعة: نظام الملاحظات الإدارية (Admin Notes)</h3>
                  <p className="text-xs text-slate-500">التسجيل الصوتي الفوري وتحويله لنصوص وتوجيهها للإدارات المعنية بالسكرتارية.</p>
                </div>
                <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4 text-center">
                  <div className="w-16 h-16 rounded-full bg-red-100 dark:bg-red-950/50 text-red-600 flex items-center justify-center mx-auto text-xl shadow-lg animate-pulse">
                    🎤
                  </div>
                  <h4 className="text-sm font-bold">اضغط لبدء تسجيل الملاحظة الإدارية الصوتیة</h4>
                  <p className="text-xs text-slate-400">سيتم تحويل الكلام إلى نص بدقة عالية وتوجيهه لقسم الإدارة المختصة في السكرتارية.</p>
                  <button
                    onClick={() => {
                      showToast('تم تحويل التسجيل إلى نص وتوجيهه لسجلات السكرتارية بنجاح');
                    }}
                    className="px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold"
                  >
                    بدء / إيقاف التسجيل الصوتي
                  </button>
                </div>
              </div>
            )}

            {quickTab === 'ideas' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-bold">الوحدة الخامسة: الأفكار السريعة (Quick Ideas)</h3>
                    <p className="text-xs text-slate-500">تسجيل ومضات التفكير الاستراتيجي والحفظ التلقائي في قسم "المسودات" موسومة بـ "فكرة سريعة".</p>
                  </div>
                  <button
                    onClick={() => {
                      createDraftHandler({
                        id: makeSafeId('draft'),
                        title: `فكرة سريعة استراتيجية - ${new Date().toLocaleDateString('ar-EG')}`,
                        content: 'تم الالتقاط الصوتي الفكري السريع من البوابة الذكية.',
                        scope: 'factory',
                        projectId: selectedProjectId || '',
                        pinned: true
                      });
                      showToast('تم حفظ الفكرة السريعة في قسم المسودات بنجاح');
                    }}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold"
                  >
                    + حفظ فكرة جديدة كمسودة
                  </button>
                </div>
                <div className="p-4 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-200 dark:border-indigo-800 text-xs text-indigo-900 dark:text-indigo-200">
                  الأفكار المسجلة يتم أرشفقتها فوراً ومزامنتها مع سجلات المسودات الاستراتيجية لإدارة البيئة.
                </div>
              </div>
            )}

            {quickTab === 'booking' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-bold">الوحدة السادسة: حجز العمل (Work Booking)</h3>
                    <p className="text-xs text-slate-500">تنظيم المواعيد والمواقع الميدانية وربطها بسجلات المتابعة.</p>
                  </div>
                  <button
                    onClick={() => {
                      createOrderHandler({
                        id: makeSafeId('ord'),
                        refCode: `BOOK-${Math.floor(100 + Math.random() * 900)}`,
                        title: 'حجز مهمة ميدانية بيئية جديدة',
                        details: 'معاينة ميدانية لوحدة معالجة المخلفات.',
                        domain: 'company',
                        projectId: selectedProjectId || '',
                        issuer: 'د. أيمن عبد الحميد',
                        assigneeOrUnit: 'فريق التفتيش الميداني',
                        subDepartment: 'التفتيش البيئي',
                        technicians: ['مهندس الحين', 'مفتش السلامة'],
                        isAssigned: true,
                        priority: 'high',
                        status: 'new',
                        dueDate: new Date().toISOString().slice(0, 10),
                        linkedFileIds: []
                      });
                      showToast('تم حجز مهمة العمل الميداني وربطها بسجلات المتابعة بنجاح');
                    }}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold"
                  >
                    + حجز مهمة ميدانية جديدة
                  </button>
                </div>
                <div className="space-y-2">
                  {workspace.orders.map((o) => (
                    <div key={o.id} className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-mono font-bold text-indigo-600">{o.refCode}</span> — <strong>{o.title}</strong>
                        <div className="text-[11px] text-slate-500 mt-0.5">المسؤول: {o.assigneeOrUnit} · الموعد: {o.dueDate}</div>
                      </div>
                      <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold">مؤكد</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {quickTab === 'report' && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-base font-bold">الوحدة السابعة: التقارير والجدول اليومي (Daily Report & Schedule)</h3>
                  <p className="text-xs text-slate-500">إصدار ملخص صوتي صباحي بجدول الأعمال، وحصر الملاحظات غير المنتهية والأفكار لإعادة جدولتها.</p>
                </div>
                <div className="p-6 rounded-2xl bg-slate-900 text-white space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-indigo-400 font-bold uppercase tracking-wider">الملخص الصباحي الذكي</span>
                    <span className="text-xs text-slate-400 font-mono">2026-11-24</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    صباح الخير يا فخامة المدير العام د. أيمن عبد الحميد. لديك اليوم 3 اجتماعات ميدانية، و5 ملاحظات إدارية تنتظر التوجيه، و2 أفكار استراتيجية مسجلة حديثاً.
                  </p>
                  <button
                    onClick={() => showToast('جاري تشغيل الملخص الصوتي الصباحي للأجندة...')}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold"
                  >
                    🔊 استماع للملخص الصوتي الصباحي
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        <footer className="text-center py-6 text-xs text-slate-400 dark:text-slate-500 border-t border-slate-200 dark:border-slate-800 mt-12 w-full">
          <p className="font-semibold">إنتاج أحمد جلال</p>
          <p className="mt-0.5 font-mono">2026</p>
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex">
      <Sidebar
        section={section}
        externalFilterDirection={externalDir}
        memoFilterDirection={memoDir}
        draftScopeFilter={draftScopeFilter}
        selectedSubDept={selectedSubDept}
        selectedProjectId={selectedProjectId}
        projects={workspace.projects}
        counts={counts}
        user={user}
        localMode={localMode}
        isOnline={isOnline}
        hasPendingSync={hasPendingSync}
        darkMode={darkMode}
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
        onSelectSection={setSection}
        onSelectExternalDirection={setExternalDir}
        onSelectSubDept={setSelectedSubDept}
        onSelectMemoDirection={setMemoDir}
        onSelectDraftScope={setDraftScopeFilter}
        onSelectProject={setSelectedProjectId}
        onNewFolder={() => {
          setEditingProject(null);
          setActiveModal('project');
        }}
        onOpenSyncModal={() => setSyncModalOpen(true)}
        onSwitchToOffline={handleSwitchToOffline}
        onOpenOfflineModal={() => setOfflineModalOpen(true)}
        onOpenClearModal={() => setClearModalOpen(true)}
        onToggleDark={() => setDarkMode((v) => !v)}
        onSignOut={handleSignOut}
      />

      <div className="flex-1 flex flex-col min-w-0">
        <TopBar
          section={section}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          selectedProject={selectedProjectObj}
          onClearProject={() => setSelectedProjectId(null)}
          user={user}
          localMode={localMode}
          isOnline={isOnline}
          hasPendingSync={hasPendingSync}
          onOpenMobileMenu={() => setMobileMenuOpen(true)}
          onQuickAdd={openQuickAdd}
          onOpenOfflineModal={() => setOfflineModalOpen(true)}
          onOpenSyncModal={() => setSyncModalOpen(true)}
          onReturnToPortal={() => setAppMode('portal')}
        />

        <main className="no-print flex-1 p-4 lg:p-6 max-w-7xl w-full mx-auto">
          <NewFolderBanner
            folderInfo={folderInfo}
            isStandaloneOffline={standaloneOffline}
            onConnectFolder={handleConnectNewFolder}
            onReconnectFolder={handleReconnectNewFolder}
            onDownloadZipFolder={handleDownloadNewFolderZip}
            onDownloadDbJson={handleDownloadDbJson}
            onImportFolderFiles={handleImportNewFolderFiles}
          />

          {/* Online Sync Reminder Banner when offline edits exist */}
          {!standaloneOffline && isOnline && (localMode || hasPendingSync) && (
            <div className="mb-4 p-3 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs text-blue-900 dark:text-blue-200">
                <Wifi className="w-4 h-4 text-blue-700 dark:text-blue-400 shrink-0" />
                <span>
                  {hasPendingSync
                    ? 'لديك تعديلات محلية أثناء الأوفلاين جاهزة للمزامنة مع السحابة الآن.'
                    : 'أنت تعمل الآن بالوضع المحلي — يمكنك الربط والمزامنة مع السحابة في أي وقت.'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setSyncModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>طلب المزامنة الآن</span>
              </button>
            </div>
          )}

          {searchQuery.trim() && (
            <LiveSearchPanel
              query={searchQuery}
              hits={searchHits}
              projects={workspace.projects}
              onInspect={setInspected}
            />
          )}

          {section === 'overview' && (
            <OverviewView
              workspace={scopedWorkspace}
              onNavigate={setSection}
              onSelectSubDept={setSelectedSubDept}
              onInspect={setInspected}
            />
          )}

          {section === 'external' && (
            <ExternalCorrespondenceView
              entities={workspace.correspondenceEntities}
              correspondences={workspace.correspondences}
              filterDirection={externalDir}
              onChangeDirection={setExternalDir}
              onAddEntity={() => setActiveModal('entity')}
              onAddCorrespondence={(entId) => {
                setReplyToCorr(null);
                setModalDefaultEntityId(entId || '');
                setActiveModal('correspondence');
              }}
              onReplyCorrespondence={(corr) => {
                setReplyToCorr(corr);
                setActiveModal('correspondence');
              }}
              onDeleteEntity={deleteEntityHandler}
              onDeleteCorrespondence={deleteCorrHandler}
              onInspect={setInspected}
              onPrintMemo={handlePrintMemo}
            />
          )}

          {section === 'sub_departments' && (
            <SubDepartmentsView
              selectedSubDept={selectedSubDept}
              onSelectSubDept={setSelectedSubDept}
              orders={scopedWorkspace.orders}
              correspondences={workspace.correspondences}
              onAddOrderForDept={(deptName) => {
                setModalDefaultSubDept(deptName);
                setActiveModal('order');
              }}
              onAddCorrForDept={(deptName) => {
                setReplyToCorr(null);
                setModalDefaultSubDept(deptName);
                setActiveModal('correspondence');
              }}
              onInspect={setInspected}
              onDeleteOrder={deleteOrderHandler}
            />
          )}

          {section === 'memos' && (
            <MemosView
              memos={scopedWorkspace.memos}
              files={scopedWorkspace.files}
              direction={memoDir}
              onChangeDirection={setMemoDir}
              onAddMemo={(dir) => {
                setReplyToMemo(null);
                setMemoDir(dir);
                setActiveModal('memo');
              }}
              onReplyMemo={(memo) => {
                setReplyToMemo(memo);
                setActiveModal('memo');
              }}
              onDeleteMemo={deleteMemoHandler}
              onDeleteFile={deleteFileHandler}
              onInspect={setInspected}
              onPrintMemo={handlePrintMemo}
            />
          )}

          {section === 'drafts' && (
            <DraftsView
              drafts={scopedWorkspace.drafts}
              scopeFilter={draftScopeFilter}
              onChangeScopeFilter={setDraftScopeFilter}
              onAddDraft={(scope) => {
                setDraftScopeFilter(scope);
                setActiveModal('draft');
              }}
              onDeleteDraft={deleteDraftHandler}
              onInspect={setInspected}
              onPrintMemo={handlePrintMemo}
            />
          )}

          {section === 'folders' && (
            <FoldersView
              workspace={workspace}
              selectedProjectId={selectedProjectId}
              onSelectProject={setSelectedProjectId}
              onNewFolder={() => {
                setEditingProject(null);
                setActiveModal('project');
              }}
              onEditFolder={(proj) => {
                setEditingProject(proj);
                setActiveModal('project');
              }}
              onDeleteFolder={deleteProjectHandler}
            />
          )}

          {section === 'orders' && (
            <OrdersView
              orders={scopedWorkspace.orders}
              onAddOrder={() => setActiveModal('order')}
              onUpdateOrder={updateOrderHandler}
              onDeleteOrder={deleteOrderHandler}
              onFollowUpOrder={followUpOrderHandler}
              onInspect={setInspected}
            />
          )}

          {section === 'research' && (
            <ResearchView
              files={scopedWorkspace.files}
              defaultProjectId={selectedProjectId || ''}
              onAddResearchModal={() => setActiveModal('research')}
              onCreateFile={createFileHandler}
              onDeleteFile={deleteFileHandler}
              onInspect={setInspected}
              onToast={showToast}
            />
          )}

          {section === 'files' && (
            <FilesView
              files={scopedWorkspace.files}
              projects={workspace.projects}
              defaultProjectId={selectedProjectId || ''}
              onAddFileModal={() => setActiveModal('file')}
              onCreateFile={createFileHandler}
              onUpdateFile={updateFileHandler}
              onDeleteFile={deleteFileHandler}
              onInspect={setInspected}
              onToast={showToast}
            />
          )}

          {section === 'images' && (
            <ImagesView
              images={scopedWorkspace.images}
              projects={workspace.projects}
              defaultProjectId={selectedProjectId || ''}
              onAddImageModal={() => setActiveModal('image')}
              onCreateImage={createImageHandler}
              onDeleteImage={deleteImageHandler}
              onInspect={setInspected}
              onToast={showToast}
            />
          )}
        </main>
      </div>

      {/* Inspector Drawer */}
      <InspectorDrawer
        inspected={inspected}
        workspace={workspace}
        onClose={() => setInspected(null)}
        onInspect={setInspected}
        onUpdateFile={updateFileHandler}
        onDeleteFile={deleteFileHandler}
        onUpdateImage={updateImageHandler}
        onDeleteImage={deleteImageHandler}
        onUpdateMemo={updateMemoHandler}
        onDeleteMemo={deleteMemoHandler}
        onReplyMemo={(memo) => {
          setInspected(null);
          setReplyToMemo(memo);
          setActiveModal('memo');
        }}
        onUpdateDraft={updateDraftHandler}
        onDeleteDraft={deleteDraftHandler}
        onUpdateOrder={updateOrderHandler}
        onDeleteOrder={deleteOrderHandler}
        onFollowUpOrder={followUpOrderHandler}
        onUpdateCorrespondence={updateCorrHandler}
        onDeleteCorrespondence={deleteCorrHandler}
        onReplyCorrespondence={(corr) => {
          setInspected(null);
          setReplyToCorr(corr);
          setActiveModal('correspondence');
        }}
        onDeleteMessage={deleteMessageHandler}
        onPrintMemo={handlePrintMemo}
        onToast={showToast}
      />

      {/* Modals */}
      <WorkspaceModals
        modal={activeModal}
        projects={workspace.projects}
        entities={workspace.correspondenceEntities}
        defaultProjectId={selectedProjectId || ''}
        defaultMemoDirection={memoDir}
        defaultDraftScope={draftScopeFilter === 'private' ? 'private' : 'factory'}
        defaultSubDepartment={modalDefaultSubDept}
        defaultEntityId={modalDefaultEntityId}
        editingProject={editingProject}
        replyToMemo={replyToMemo}
        replyToCorrespondence={replyToCorr}
        onClose={() => {
          setActiveModal(null);
          setEditingProject(null);
          setReplyToMemo(null);
          setReplyToCorr(null);
        }}
        onCreateEntity={createEntityHandler}
        onCreateCorrespondence={createCorrHandler}
        onCreateProject={createProjectHandler}
        onUpdateProject={updateProjectHandler}
        onCreateFile={createFileHandler}
        onCreateImage={createImageHandler}
        onCreateMemo={createMemoHandler}
        onCreateDraft={createDraftHandler}
        onCreateOrder={createOrderHandler}
        onPrintMemo={handlePrintMemo}
        onToast={showToast}
      />

      <SyncModal
        open={syncModalOpen}
        user={user}
        localMode={localMode}
        isOnline={isOnline}
        hasPendingSync={hasPendingSync}
        lastSyncedAt={lastSyncedAt}
        linkedHint={linkedHint}
        workspace={workspace}
        onClose={() => setSyncModalOpen(false)}
        onLinkGoogle={handleLinkGoogle}
        onExecuteSync={handleExecuteSync}
        onCleanCloudForDev={handleCleanCloudForDev}
        onSwitchToOffline={handleSwitchToOffline}
        onSwitchToOnline={handleSwitchToOnline}
        onMergeImportedJson={handleImportBackup}
        onSignOutGoogle={handleSignOut}
        onToast={showToast}
      />

      <OfflineDownloadModal
        open={offlineModalOpen}
        workspace={workspace}
        folderInfo={folderInfo}
        onConnectNewFolder={handleConnectNewFolder}
        onReconnectNewFolder={handleReconnectNewFolder}
        onDownloadNewFolderZip={handleDownloadNewFolderZip}
        onDownloadDbJson={handleDownloadDbJson}
        onImportNewFolderFiles={handleImportNewFolderFiles}
        onClose={() => setOfflineModalOpen(false)}
        onImportBackup={handleImportBackup}
        onOpenClearModal={() => setClearModalOpen(true)}
        onToast={showToast}
      />

      <ClearWorkspaceModal
        open={clearModalOpen}
        workspace={workspace}
        onClose={() => setClearModalOpen(false)}
        onConfirmClear={handleClearWorkspace}
        onCleanNonEssential={handleCleanNonEssential}
        onToast={showToast}
      />

      {/* A4 Print Layer */}
      <MemoA4PrintSheet memo={printMemo} />

      {/* Toast Notification */}
      {toastMsg && (
        <div
          role="status"
          className="no-print fixed bottom-5 left-5 z-50 px-4 py-2.5 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 text-xs font-bold shadow-xl border border-slate-700 dark:border-slate-200"
        >
          {toastMsg}
        </div>
      )}
    </div>
  );
}

export function App() {
  return (
    <ErrorBoundary>
      <WorkspaceApp />
    </ErrorBoundary>
  );
}

export default App;
